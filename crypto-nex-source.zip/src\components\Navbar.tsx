import React from 'react';
import { useApp } from '../context/AppContext';
import { Shield, Activity, FileText, Cpu, ChevronDown } from 'lucide-react';
import { BlockchainNetwork } from '../types';

export const Navbar: React.FC = () => {
  const { selectedNetwork, setSelectedNetwork, setIsReportModalOpen, attribution } = useApp();

  const networks: { id: BlockchainNetwork; name: string; color: string }[] = [
    { id: 'ethereum', name: 'Ethereum Mainnet', color: 'bg-indigo-500' },
    { id: 'polygon', name: 'Polygon PoS', color: 'bg-purple-500' },
    { id: 'arbitrum', name: 'Arbitrum One', color: 'bg-cyan-500' },
    { id: 'bsc', name: 'BNB Smart Chain', color: 'bg-amber-500' },
  ];

  return (
    <header className="h-16 border-b border-slate-800/80 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40 px-6 flex items-center justify-between">
      {/* Brand & Logo */}
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-gradient-to-tr from-cyan-600 via-indigo-600 to-violet-600 p-[1.5px] shadow-lg shadow-cyan-500/20">
            <div className="h-full w-full bg-slate-950 rounded-[10px] flex items-center justify-center">
              <Shield className="h-5 w-5 text-cyan-400" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display font-extrabold text-xl tracking-wider bg-gradient-to-r from-cyan-400 via-sky-300 to-indigo-400 bg-clip-text text-transparent">
                CRYPTO-NEX
              </span>
              <span className="text-[10px] uppercase font-mono tracking-widest px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                SIH 2026
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-mono hidden sm:block">
              Blockchain Intelligence for Automated VASP Attribution
            </p>
          </div>
        </div>
      </div>

      {/* Center Intelligence Telemetry Badge */}
      <div className="hidden lg:flex items-center gap-3 px-3 py-1.5 rounded-lg bg-slate-900/60 border border-slate-800 text-xs text-slate-300">
        <div className="flex items-center gap-1.5">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <span className="font-medium text-emerald-400">ML Heuristic Active</span>
        </div>
        <span className="text-slate-600">|</span>
        <div className="flex items-center gap-1 text-slate-400">
          <Cpu className="h-3.5 w-3.5 text-cyan-400" />
          <span>Multi-Hop Graph Topology</span>
        </div>
        <span className="text-slate-600">|</span>
        <span className="text-[11px] font-mono text-amber-400/90 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20">
          Probabilistic v1.0
        </span>
      </div>

      {/* Right Controls & Network Selector */}
      <div className="flex items-center gap-3">
        {/* Network Selector */}
        <div className="relative">
          <select
            value={selectedNetwork}
            onChange={(e) => setSelectedNetwork(e.target.value as BlockchainNetwork)}
            aria-label="Blockchain Network Selection"
            className="appearance-none bg-slate-900/90 border border-slate-700/80 rounded-lg pl-8 pr-8 py-1.5 text-xs text-slate-200 font-mono focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 cursor-pointer"
          >
            {networks.map((net) => (
              <option key={net.id} value={net.id}>
                {net.name}
              </option>
            ))}
          </select>
          <div className="absolute left-2.5 top-1/2 -translate-y-1/2 pointer-events-none">
            <span className={`inline-block h-2 w-2 rounded-full ${networks.find(n => n.id === selectedNetwork)?.color}`} />
          </div>
          <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-400 pointer-events-none" />
        </div>

        {/* Generate Report Button */}
        <button
          onClick={() => setIsReportModalOpen(true)}
          disabled={!attribution}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-medium shadow-md shadow-cyan-900/30 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <FileText className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">Export Intelligence Report</span>
          <span className="sm:hidden">Report</span>
        </button>
      </div>
    </header>
  );
};
