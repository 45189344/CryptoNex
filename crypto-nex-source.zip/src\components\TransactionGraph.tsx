import React, { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { GraphNode, GraphEdge } from '../types';
import { 
  Network, ZoomIn, ZoomOut, RotateCcw, Filter, 
  Layers, ShieldAlert, CheckCircle2, Info, Eye 
} from 'lucide-react';

export const TransactionGraph: React.FC<{ fullscreen?: boolean }> = ({ fullscreen = false }) => {
  const { graph, isAnalyzing, setInspectedNode, maxHops, setMaxHops } = useApp();
  
  const [zoom, setZoom] = useState<number>(1);
  const [pan, setPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState<boolean>(false);
  const [dragStart, setDragStart] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [filterVaspOnly, setFilterVaspOnly] = useState<boolean>(false);
  const [hoveredNode, setHoveredNode] = useState<GraphNode | null>(null);

  // Position nodes radially based on Hop level
  const computedNodes = React.useMemo(() => {
    if (!graph || graph.nodes.length === 0) return [];

    const nodes = [...graph.nodes];
    const width = 800;
    const height = 500;
    const centerX = width / 2;
    const centerY = height / 2;

    const hopGroups: Record<number, GraphNode[]> = { 0: [], 1: [], 2: [], 3: [] };
    nodes.forEach(n => {
      const h = n.hop || 0;
      if (!hopGroups[h]) hopGroups[h] = [];
      hopGroups[h].push(n);
    });

    const positionedNodes: (GraphNode & { x: number; y: number })[] = [];

    // Target Node at Center
    if (hopGroups[0].length > 0) {
      positionedNodes.push({ ...hopGroups[0][0], x: centerX, y: centerY });
    }

    // Hop 1 Ring
    const hop1Radius = 160;
    const hop1Nodes = hopGroups[1];
    hop1Nodes.forEach((node, i) => {
      const angle = (i / hop1Nodes.length) * 2 * Math.PI - Math.PI / 2;
      positionedNodes.push({
        ...node,
        x: centerX + hop1Radius * Math.cos(angle),
        y: centerY + hop1Radius * Math.sin(angle),
      });
    });

    // Hop 2 Ring
    const hop2Radius = 270;
    const hop2Nodes = hopGroups[2];
    hop2Nodes.forEach((node, i) => {
      const angle = (i / Math.max(1, hop2Nodes.length)) * 2 * Math.PI - Math.PI / 3;
      positionedNodes.push({
        ...node,
        x: centerX + hop2Radius * Math.cos(angle),
        y: centerY + hop2Radius * Math.sin(angle),
      });
    });

    // Hop 3 Ring
    const hop3Radius = 360;
    const hop3Nodes = hopGroups[3];
    hop3Nodes.forEach((node, i) => {
      const angle = (i / Math.max(1, hop3Nodes.length)) * 2 * Math.PI - Math.PI / 4;
      positionedNodes.push({
        ...node,
        x: centerX + hop3Radius * Math.cos(angle),
        y: centerY + hop3Radius * Math.sin(angle),
      });
    });

    return positionedNodes;
  }, [graph]);

  const filteredNodes = React.useMemo(() => {
    if (!filterVaspOnly) return computedNodes;
    return computedNodes.filter(n => n.isTarget || n.isVASP || n.type === 'HIGH_RISK_ENTITY');
  }, [computedNodes, filterVaspOnly]);

  const nodeMap = React.useMemo(() => {
    const map = new Map<string, GraphNode & { x: number; y: number }>();
    computedNodes.forEach(n => map.set(n.id.toLowerCase(), n));
    return map;
  }, [computedNodes]);

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging) {
      setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
    }
  };

  const handleMouseUp = () => setIsDragging(false);

  const resetView = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  if (isAnalyzing) {
    return (
      <div className={`rounded-2xl glass-panel flex flex-col items-center justify-center text-center ${fullscreen ? 'h-[750px]' : 'h-[500px]'}`}>
        <div className="h-14 w-14 rounded-full border-4 border-cyan-500/30 border-t-cyan-400 animate-spin mb-3" />
        <h4 className="text-sm font-semibold text-slate-200">Generating Topology Graph</h4>
        <p className="text-xs text-slate-500 font-mono mt-1">Tracing multi-hop transaction flows and VASP clusters...</p>
      </div>
    );
  }

  if (!graph || graph.nodes.length === 0) {
    return (
      <div className={`rounded-2xl glass-panel flex flex-col items-center justify-center text-center text-slate-500 ${fullscreen ? 'h-[750px]' : 'h-[500px]'}`}>
        <Network className="h-12 w-12 text-slate-700 mb-2" />
        <p className="text-sm">No transaction graph data available.</p>
        <p className="text-xs">Run wallet analysis to construct the interactive graph.</p>
      </div>
    );
  }

  return (
    <div className={`rounded-2xl glass-panel relative overflow-hidden flex flex-col ${fullscreen ? 'h-[calc(100vh-10rem)]' : 'h-[550px]'}`}>
      {/* Top Toolbar */}
      <div className="px-5 py-3 border-b border-slate-800/80 bg-slate-950/60 backdrop-blur-md flex flex-wrap items-center justify-between gap-3 z-10">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2">
            <Network className="h-4 w-4 text-cyan-400" />
            <span className="font-semibold text-sm text-slate-200 font-display">Interactive Multi-Hop Graph</span>
          </div>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
            {graph.nodes.length} Nodes / {graph.edges.length} Edges
          </span>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          {/* VASP filter toggle */}
          <button
            onClick={() => setFilterVaspOnly(!filterVaspOnly)}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs rounded-lg font-mono transition-all ${
              filterVaspOnly
                ? 'bg-cyan-500 text-slate-950 font-semibold'
                : 'bg-slate-900 text-slate-400 border border-slate-700 hover:text-slate-200'
            }`}
          >
            <Filter className="h-3 w-3" />
            <span>VASPs Only</span>
          </button>

          {/* Depth toggle */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded-lg p-0.5 text-xs font-mono">
            {[1, 2, 3].map((h) => (
              <button
                key={h}
                onClick={() => setMaxHops(h)}
                className={`px-2 py-0.5 rounded ${maxHops === h ? 'bg-cyan-500/20 text-cyan-300 font-bold' : 'text-slate-400'}`}
              >
                {h}H
              </button>
            ))}
          </div>

          {/* Zoom controls */}
          <div className="flex items-center gap-1 bg-slate-900 border border-slate-700 rounded-lg p-0.5">
            <button
              onClick={() => setZoom(z => Math.min(2.5, z + 0.2))}
              className="p-1 text-slate-400 hover:text-cyan-300 transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setZoom(z => Math.max(0.5, z - 0.2))}
              className="p-1 text-slate-400 hover:text-cyan-300 transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={resetView}
              className="p-1 text-slate-400 hover:text-cyan-300 transition-colors"
              title="Reset View"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* SVG Canvas Graph Area */}
      <div 
        className="flex-1 w-full h-full relative cursor-grab active:cursor-grabbing bg-slate-950/80 bg-grid-pattern overflow-hidden select-none"
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <svg
          className="w-full h-full"
          viewBox="0 0 800 500"
          style={{
            transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`,
            transformOrigin: 'center center',
            transition: isDragging ? 'none' : 'transform 0.15s ease-out'
          }}
        >
          <defs>
            {/* Arrow Marker */}
            <marker id="arrow" viewBox="0 0 10 10" refX="18" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
              <path d="M 0 0 L 10 5 L 0 10 z" fill="#06b6d4" opacity="0.6" />
            </marker>
            {/* Glow Filters */}
            <filter id="glow-target" x="-50%" y="-50%" width="200%" height="200%">
              <feDropShadow dx="0" dy="0" stdDeviation="6" floodColor="#06b6d4" floodOpacity="0.8" />
            </filter>
            <filter id="glow-vasp" x="-50%" y="-50%" width="200%" height="200%">
              <feDropShadow dx="0" dy="0" stdDeviation="5" floodColor="#10b981" floodOpacity="0.7" />
            </filter>
            <filter id="glow-risk" x="-50%" y="-50%" width="200%" height="200%">
              <feDropShadow dx="0" dy="0" stdDeviation="6" floodColor="#f43f5e" floodOpacity="0.8" />
            </filter>
          </defs>

          {/* Concentric Hop Rings */}
          <circle cx="400" cy="250" r="160" fill="none" stroke="rgba(51, 65, 85, 0.25)" strokeDasharray="4 4" />
          <circle cx="400" cy="250" r="270" fill="none" stroke="rgba(51, 65, 85, 0.20)" strokeDasharray="4 4" />
          <circle cx="400" cy="250" r="360" fill="none" stroke="rgba(51, 65, 85, 0.15)" strokeDasharray="4 4" />

          {/* Edges */}
          <g className="edges">
            {graph.edges.map((edge) => {
              const src = nodeMap.get(edge.source.toLowerCase());
              const tgt = nodeMap.get(edge.target.toLowerCase());
              if (!src || !tgt) return null;

              return (
                <g key={edge.id}>
                  <line
                    x1={src.x}
                    y1={src.y}
                    x2={tgt.x}
                    y2={tgt.y}
                    stroke={tgt.isVASP ? 'rgba(6, 182, 212, 0.6)' : 'rgba(71, 85, 105, 0.5)'}
                    strokeWidth={Math.max(1.5, Math.min(5, edge.totalValue * 0.4))}
                    markerEnd="url(#arrow)"
                    className="transition-all hover:stroke-cyan-400 hover:stroke-[3px]"
                  />
                </g>
              );
            })}
          </g>

          {/* Nodes */}
          <g className="nodes">
            {filteredNodes.map((node) => {
              const isTarget = !!node.isTarget;
              const isVasp = !!node.isVASP;
              const isRisk = node.type === 'HIGH_RISK_ENTITY';

              let fill = '#1e293b';
              let stroke = '#475569';
              let filter = '';
              let radius = 18;

              if (isTarget) {
                fill = '#0891b2';
                stroke = '#22d3ee';
                filter = 'url(#glow-target)';
                radius = 24;
              } else if (isRisk) {
                fill = '#9f1239';
                stroke = '#f43f5e';
                filter = 'url(#glow-risk)';
                radius = 22;
              } else if (isVasp) {
                fill = '#065f46';
                stroke = '#34d399';
                filter = 'url(#glow-vasp)';
                radius = 22;
              }

              return (
                <g
                  key={node.id}
                  transform={`translate(${node.x}, ${node.y})`}
                  className="cursor-pointer group"
                  onClick={() => setInspectedNode(node)}
                  onMouseEnter={() => setHoveredNode(node)}
                  onMouseLeave={() => setHoveredNode(null)}
                >
                  {/* Outer pulse for Target & VASP */}
                  {(isTarget || isVasp || isRisk) && (
                    <circle
                      r={radius + 6}
                      fill="none"
                      stroke={stroke}
                      strokeWidth="1.5"
                      opacity="0.4"
                      className="animate-pulse"
                    />
                  )}

                  {/* Main Node Body */}
                  <circle
                    r={radius}
                    fill={fill}
                    stroke={stroke}
                    strokeWidth="2.5"
                    filter={filter}
                    className="transition-transform group-hover:scale-110"
                  />

                  {/* Hop Badge */}
                  <circle
                    cx={radius - 4}
                    cy={-radius + 4}
                    r="8"
                    fill="#0f172a"
                    stroke={stroke}
                    strokeWidth="1"
                  />
                  <text
                    x={radius - 4}
                    y={-radius + 7}
                    textAnchor="middle"
                    fill="#f1f5f9"
                    fontSize="9"
                    fontWeight="bold"
                    fontFamily="monospace"
                  >
                    {node.hop}H
                  </text>

                  {/* Text Label Below Node */}
                  <text
                    y={radius + 14}
                    textAnchor="middle"
                    fill={isTarget ? '#38bdf8' : isVasp ? '#6ee7b7' : isRisk ? '#fda4af' : '#cbd5e1'}
                    fontSize="10"
                    fontWeight="600"
                    fontFamily="sans-serif"
                    className="pointer-events-none drop-shadow-md"
                  >
                    {node.vaspName || (isTarget ? 'TARGET' : `${node.address.slice(0, 6)}...`)}
                  </text>
                </g>
              );
            })}
          </g>
        </svg>

        {/* Hover Tooltip Overlay */}
        {hoveredNode && (
          <div className="absolute bottom-4 left-4 p-3 rounded-xl bg-slate-900/90 backdrop-blur-md border border-slate-700 text-xs font-mono space-y-1 pointer-events-none z-20 shadow-2xl">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-100">{hoveredNode.label}</span>
              {hoveredNode.isVASP && (
                <span className="px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300 text-[10px]">
                  VASP Identified
                </span>
              )}
            </div>
            <div className="text-slate-400 text-[11px] truncate max-w-xs">{hoveredNode.address}</div>
            <div className="flex items-center gap-3 text-[11px] text-cyan-300 pt-1 border-t border-slate-800">
              <span>Hop: {hoveredNode.hop}</span>
              <span>Volume: {hoveredNode.totalVolume.toFixed(2)} ETH</span>
              <span>TXs: {hoveredNode.txCount}</span>
            </div>
          </div>
        )}

        {/* Bottom Graph Legend */}
        <div className="absolute bottom-4 right-4 p-2.5 rounded-xl bg-slate-900/80 backdrop-blur-md border border-slate-800 flex items-center gap-4 text-[11px] font-mono z-10">
          <div className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-full bg-cyan-500 border border-cyan-300 shadow-sm shadow-cyan-500/50" />
            <span className="text-slate-300">Target</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-full bg-emerald-600 border border-emerald-400" />
            <span className="text-slate-300">VASP Cluster</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-full bg-slate-700 border border-slate-500" />
            <span className="text-slate-300">Intermediary Relay</span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="h-3 w-3 rounded-full bg-rose-700 border border-rose-400" />
            <span className="text-slate-300">High Risk / Mixer</span>
          </div>
        </div>
      </div>
    </div>
  );
};
