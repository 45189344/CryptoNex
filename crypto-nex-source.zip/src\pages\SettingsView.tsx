import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { apiClient } from '../api/client';
import { 
  Sliders, RotateCcw, Save, CheckCircle2, 
  Cpu, Database, Network, ShieldCheck, Activity 
} from 'lucide-react';
import { ScoringWeights } from '../types';

export const SettingsView: React.FC = () => {
  const { weights, updateWeights } = useApp();

  const [formWeights, setFormWeights] = useState({
    graphProximity: Math.round(weights.graphProximity * 100),
    transactionVolume: Math.round(weights.transactionVolume * 100),
    interactionFrequency: Math.round(weights.interactionFrequency * 100),
    behavioralSimilarity: Math.round(weights.behavioralSimilarity * 100),
    temporalPattern: Math.round(weights.temporalPattern * 100),
  });

  const [health, setHealth] = useState<any>(null);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    apiClient.getHealth().then(res => setHealth(res)).catch(() => {});
  }, []);

  const totalSum = 
    formWeights.graphProximity + 
    formWeights.transactionVolume + 
    formWeights.interactionFrequency + 
    formWeights.behavioralSimilarity + 
    formWeights.temporalPattern;

  const handleSliderChange = (key: keyof typeof formWeights, val: number) => {
    setFormWeights(prev => ({ ...prev, [key]: val }));
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (totalSum !== 100) return;

    await updateWeights({
      graphProximity: formWeights.graphProximity / 100,
      transactionVolume: formWeights.transactionVolume / 100,
      interactionFrequency: formWeights.interactionFrequency / 100,
      behavioralSimilarity: formWeights.behavioralSimilarity / 100,
      temporalPattern: formWeights.temporalPattern / 100,
    });

    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 3000);
  };

  const handleResetDefaults = () => {
    setFormWeights({
      graphProximity: 30,
      transactionVolume: 25,
      interactionFrequency: 20,
      behavioralSimilarity: 15,
      temporalPattern: 10,
    });
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <div>
        <h1 className="text-2xl font-bold font-display text-white flex items-center gap-2">
          <Sliders className="h-6 w-6 text-cyan-400" />
          Configurable Attribution Scoring Weights
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Adjust the 5-factor mathematical weighting model. Attribution probabilities dynamically update in real time.
        </p>
      </div>

      {/* Weights Configuration Form */}
      <form onSubmit={handleSave} className="p-6 rounded-2xl glass-panel space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="text-sm font-semibold text-slate-200 font-display">
            Multi-Factor Mathematical Weights
          </h3>
          <div className="flex items-center gap-2">
            <span className={`text-xs font-mono font-bold px-2.5 py-1 rounded-lg ${
              totalSum === 100 ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40' : 'bg-rose-500/20 text-rose-300 border border-rose-500/40'
            }`}>
              Total: {totalSum}% {totalSum === 100 ? '✅ Valid' : '⚠️ Must sum to 100%'}
            </span>
          </div>
        </div>

        <div className="space-y-5">
          {/* Factor 1: Graph Proximity */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-slate-200">1. Graph Proximity Weight (1-3 Hops Decay)</span>
              <span className="font-bold text-cyan-400">{formWeights.graphProximity}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={formWeights.graphProximity}
              onChange={(e) => handleSliderChange('graphProximity', parseInt(e.target.value, 10))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">Shortest topological hop distance to verified VASP clusters.</p>
          </div>

          {/* Factor 2: Transaction Volume */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-slate-200">2. Transaction Volume Overlap Weight</span>
              <span className="font-bold text-emerald-400">{formWeights.transactionVolume}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={formWeights.transactionVolume}
              onChange={(e) => handleSliderChange('transactionVolume', parseInt(e.target.value, 10))}
              className="w-full accent-emerald-400 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">Ratio of cumulative funds routed to/from the candidate VASP.</p>
          </div>

          {/* Factor 3: Interaction Frequency */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-slate-200">3. Interaction Frequency Weight</span>
              <span className="font-bold text-indigo-400">{formWeights.interactionFrequency}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={formWeights.interactionFrequency}
              onChange={(e) => handleSliderChange('interactionFrequency', parseInt(e.target.value, 10))}
              className="w-full accent-indigo-400 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">Log-normalized repeat transaction count with cluster addresses.</p>
          </div>

          {/* Factor 4: Behavioral Similarity */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-slate-200">4. Behavioral Signature & Sweeper Mechanics</span>
              <span className="font-bold text-purple-400">{formWeights.behavioralSimilarity}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="60"
              value={formWeights.behavioralSimilarity}
              onChange={(e) => handleSliderChange('behavioralSimilarity', parseInt(e.target.value, 10))}
              className="w-full accent-purple-400 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">Deposit sweep profiling, ticket sizing, and contract payload patterns.</p>
          </div>

          {/* Factor 5: Temporal Pattern */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="font-bold text-slate-200">5. Temporal & Maintenance Window Clustering</span>
              <span className="font-bold text-amber-400">{formWeights.temporalPattern}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="40"
              value={formWeights.temporalPattern}
              onChange={(e) => handleSliderChange('temporalPattern', parseInt(e.target.value, 10))}
              className="w-full accent-amber-400 cursor-pointer"
            />
            <p className="text-[11px] text-slate-500">Activity synchronization with exchange settlement windows.</p>
          </div>
        </div>

        {/* Buttons */}
        <div className="flex items-center justify-between pt-4 border-t border-slate-800">
          <button
            type="button"
            onClick={handleResetDefaults}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-slate-200 text-xs font-mono flex items-center gap-1.5 transition-colors"
          >
            <RotateCcw className="h-3.5 w-3.5" />
            <span>Reset Defaults (30/25/20/15/10)</span>
          </button>

          <button
            type="submit"
            disabled={totalSum !== 100}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-bold text-xs flex items-center gap-2 shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50 cursor-pointer"
          >
            <Save className="h-4 w-4" />
            <span>Apply & Re-Calculate</span>
          </button>
        </div>

        {saveSuccess && (
          <div className="p-3 rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-xs font-mono text-center flex items-center justify-center gap-2">
            <CheckCircle2 className="h-4 w-4" />
            <span>Weights updated and active attribution models recalculated!</span>
          </div>
        )}
      </form>

      {/* Backend & Microservices Telemetry */}
      {health && (
        <div className="p-6 rounded-2xl glass-panel space-y-4">
          <h3 className="text-sm font-semibold text-slate-200 font-display flex items-center gap-2">
            <Activity className="h-4 w-4 text-cyan-400" />
            System Architecture & Service Telemetry
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Relational Database:</span>
              <span className="text-emerald-400 font-semibold">{health.services?.relationalDatabase}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Graph Database:</span>
              <span className="text-cyan-400 font-semibold">{health.services?.graphDatabase}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Python ML Analytics:</span>
              <span className="text-indigo-400 font-semibold">{health.services?.pythonAnalytics}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Demo Simulation Mode:</span>
              <span className="text-amber-400 font-semibold">Active & Safe</span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
