import React from 'react';
import { useApp } from '../context/AppContext';
import { WalletSearch } from '../components/WalletSearch';
import { VaspAttributionCard } from '../components/VaspAttributionCard';
import { RiskIndicators } from '../components/RiskIndicators';
import { 
  ShieldCheck, Database, Network, Target, 
  ArrowRight, Sparkles, AlertTriangle, Layers, Building2, FolderGit2 
} from 'lucide-react';

export const Dashboard: React.FC = () => {
  const { attribution, wallet, setActiveTab, presets, loadPreset } = useApp();

  const stats = [
    { label: 'Known VASP Entities', value: '8 Primary VASPs', change: '+3 Verified', icon: Building2, color: 'text-cyan-400' },
    { label: 'Address Clusters', value: '1,420+ Indexed', change: 'EVM Mainnet', icon: Database, color: 'text-emerald-400' },
    { label: 'Multi-Hop Max Depth', value: '3-Hop BFS', change: 'Graph Engine', icon: Network, color: 'text-indigo-400' },
    { label: 'Attribution Model', value: 'v1.0 (5-Factor)', change: 'Explainable AI', icon: Target, color: 'text-purple-400' },
  ];

  return (
    <div className="space-y-6">
      {/* Hero Welcome & Quick Search */}
      <div className="space-y-3">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
            <Sparkles className="h-3.5 w-3.5" />
            <span>SIH 2026 OFFICIAL BLOCKCHAIN INTELLIGENCE PLATFORM</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-display text-white tracking-tight">
            Automated VASP Attribution Intelligence
          </h1>
          <p className="text-sm text-slate-400 max-w-3xl leading-relaxed mt-1">
            Analyze unknown cryptocurrency wallet addresses, reconstruct multi-hop transaction graphs, and determine the most likely associated Virtual Asset Service Provider with mathematical confidence and supporting evidence.
          </p>
        </div>

        <WalletSearch />
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, idx) => {
          const Icon = stat.icon;
          return (
            <div key={idx} className="p-4 rounded-2xl glass-panel glass-panel-hover space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-mono uppercase text-slate-400">{stat.label}</span>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </div>
              <div className="text-lg font-bold font-display text-slate-100">{stat.value}</div>
              <div className="text-[10px] font-mono text-slate-500">{stat.change}</div>
            </div>
          );
        })}
      </div>

      {/* Main Attribution Results & Behavioral Signals */}
      {attribution && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-8 space-y-6">
            <VaspAttributionCard />
          </div>
          <div className="lg:col-span-4 space-y-6">
            <RiskIndicators />
            
            {/* Quick Workbench Shortcuts */}
            <div className="p-5 rounded-2xl glass-panel space-y-3">
              <h4 className="text-xs font-mono uppercase font-bold text-slate-300">
                Investigative Workbenches
              </h4>
              <div className="space-y-2">
                <button
                  onClick={() => setActiveTab('graph')}
                  className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-slate-200 transition-all group"
                >
                  <span className="flex items-center gap-2">
                    <Network className="h-4 w-4 text-cyan-400" />
                    Open Transaction Graph
                  </span>
                  <ArrowRight className="h-3.5 w-3.5 text-slate-500 group-hover:text-cyan-300 transition-colors" />
                </button>

                <button
                  onClick={() => setActiveTab('evidence')}
                  className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-slate-200 transition-all group"
                >
                  <span className="flex items-center gap-2">
                    <Target className="h-4 w-4 text-emerald-400" />
                    View 5-Factor Radar & Evidence
                  </span>
                  <ArrowRight className="h-3.5 w-3.5 text-slate-500 group-hover:text-emerald-300 transition-colors" />
                </button>

                <button
                  onClick={() => setActiveTab('investigations')}
                  className="w-full flex items-center justify-between p-3 rounded-xl bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-xs font-mono text-slate-200 transition-all group"
                >
                  <span className="flex items-center gap-2">
                    <FolderGit2 className="h-4 w-4 text-indigo-400" />
                    Save to Case Dossier
                  </span>
                  <ArrowRight className="h-3.5 w-3.5 text-slate-500 group-hover:text-indigo-300 transition-colors" />
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
