export type BlockchainNetwork = 'ethereum' | 'polygon' | 'arbitrum' | 'optimism' | 'bsc';

export type VaspType = 'CEX' | 'DEX' | 'PAYMENT_PROCESSOR' | 'CUSTODIAN' | 'BRIDGE' | 'MIXER_HIGH_RISK';

export type AddressType = 'DEPOSIT_WALLET' | 'HOT_WALLET' | 'COLD_WALLET' | 'SWEEPER' | 'CONTRACT' | 'VAULT';

export type VerificationStatus = 'VERIFIED_PUBLIC' | 'COMMUNITY_REPORTED' | 'HEURISTIC_CLUSTER' | 'DEMO_SIMULATION';

export interface VASP {
  id: string;
  name: string;
  type: VaspType;
  country: string;
  website: string;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH' | 'SANCTIONED';
  description: string;
  isVerified: boolean;
  totalIdentifiedAddresses: number;
}

export interface VASPAddress {
  id: string;
  vaspId: string;
  blockchain: BlockchainNetwork;
  address: string;
  addressType: AddressType;
  source: string;
  sourceType: string;
  confidence: number;
  verificationStatus: VerificationStatus;
  lastVerifiedDate: string;
  isDemoData: boolean;
}

export interface Transaction {
  id: string;
  txHash: string;
  fromAddress: string;
  toAddress: string;
  blockchain: BlockchainNetwork;
  value: number;
  valueUSD?: number;
  token: string;
  timestamp: number;
  blockNumber: number;
  gasPriceGwei?: number;
  isIncoming?: boolean;
}

export interface WalletStatistics {
  totalTransactions: number;
  incomingTransactions: number;
  outgoingTransactions: number;
  totalVolumeETH: number;
  totalVolumeUSD: number;
  uniqueCounterparties: number;
  firstActivity: string;
  lastActivity: string;
  avgTransactionValue: number;
  maxTransactionValue: number;
  activeDaysSpan: number;
  velocityPerHour: number;
}

export interface Wallet {
  id: string;
  address: string;
  blockchain: BlockchainNetwork;
  statistics: WalletStatistics;
  firstActivity: string;
  lastActivity: string;
  lastAnalyzedAt: string;
  riskScore?: number;
}

export interface GraphNode {
  id: string;
  label: string;
  address: string;
  type: 'TARGET' | 'INTERMEDIARY' | 'VASP_DEPOSIT' | 'VASP_HOT' | 'VASP_COLD' | 'HIGH_RISK_ENTITY';
  hop: number;
  vaspId?: string;
  vaspName?: string;
  totalVolume: number;
  txCount: number;
  isTarget?: boolean;
  isVASP?: boolean;
  isDemoData?: boolean;
  x?: number;
  y?: number;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  txCount: number;
  totalValue: number;
  token: string;
  lastTimestamp: number;
  flowDirection: 'IN' | 'OUT' | 'BIDIRECTIONAL';
}

export interface TransactionGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  targetAddress: string;
  totalHops: number;
}

export interface ScoringWeights {
  graphProximity: number;
  transactionVolume: number;
  interactionFrequency: number;
  behavioralSimilarity: number;
  temporalPattern: number;
}

export interface FactorEvidence {
  score: number;
  weightedScore: number;
  weight: number;
  metrics: Record<string, any>;
  explanation: string;
}

export interface AttributionEvidence {
  directInteractionsCount: number;
  totalInteractionsCount: number;
  shortestHopDistance: number;
  volumeOverlapETH: number;
  volumeOverlapPercent: number;
  interactionFrequencyScore: number;
  clusterSimilarityScore: number;
  behavioralPatternSummary: string;
  temporalAlignmentWindow: string;
  matchedClusters: Array<{
    clusterAddress: string;
    addressType: AddressType;
    hopDistance: number;
    flowValueETH: number;
    txCount: number;
  }>;
  factors: {
    graphProximity: FactorEvidence;
    transactionVolume: FactorEvidence;
    interactionFrequency: FactorEvidence;
    behavioralSimilarity: FactorEvidence;
    temporalPattern: FactorEvidence;
  };
}

export interface VASPAttributionRank {
  rank: number;
  vasp: VASP;
  score: number;
  rawScore: number;
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  evidence: AttributionEvidence;
  isDemoAttribution: boolean;
}

export interface RiskIndicator {
  id: string;
  severity: 'INFO' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  title: string;
  description: string;
  category: 'VELOCITY' | 'VOLUME' | 'STRUCTURING' | 'MIXER_PROXIMITY' | 'PEELING_CHAIN' | 'DORMANT_ACTIVATION';
  detectedAt?: string;
  metadata?: Record<string, any>;
}

export interface AttributionResult {
  id: string;
  walletAddress: string;
  blockchain: BlockchainNetwork;
  mostLikelyVasp: VASPAttributionRank;
  rankings: VASPAttributionRank[];
  riskIndicators: RiskIndicator[];
  modelVersion: string;
  scoringWeights: ScoringWeights;
  calculatedAt: string;
  disclaimer: string;
}

export interface InvestigationCase {
  id: string;
  walletAddress: string;
  caseTitle: string;
  investigatorNotes: string;
  status: 'OPEN' | 'IN_REVIEW' | 'COMPLETED' | 'ARCHIVED';
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  tags: string[];
  reportJson?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PresetWallet {
  address: string;
  name: string;
  description: string;
  primaryVaspExpected: string;
  expectedScore: number;
  hopsToVasp: number;
}
