export type BlockchainNetwork = 'ethereum' | 'polygon' | 'arbitrum' | 'optimism' | 'bsc';

export type VaspType = 'CEX' | 'DEX' | 'PAYMENT_PROCESSOR' | 'CUSTODIAN' | 'BRIDGE' | 'MIXER_HIGH_RISK';

export type AddressType = 'DEPOSIT_WALLET' | 'HOT_WALLET' | 'COLD_WALLET' | 'SWEEPER' | 'CONTRACT' | 'VAULT';

export type VerificationStatus = 'VERIFIED_PUBLIC' | 'COMMUNITY_REPORTED' | 'HEURISTIC_CLUSTER' | 'DEMO_SIMULATION';

export interface VASP {
  id: string;
  name: string;
  type: VaspType;
  country: string;
  website: string;
  riskRating: 'LOW' | 'MEDIUM' | 'HIGH' | 'SANCTIONED';
  description: string;
  isVerified: boolean;
  totalIdentifiedAddresses: number;
}

export interface VASPAddress {
  id: string;
  vaspId: string;
  blockchain: BlockchainNetwork;
  address: string;
  addressType: AddressType;
  source: string;
  sourceType: string;
  confidence: number; // 0.0 - 1.0
  verificationStatus: VerificationStatus;
  lastVerifiedDate: string;
  isDemoData: boolean;
}

export interface Transaction {
  id: string;
  txHash: string;
  fromAddress: string;
  toAddress: string;
  blockchain: BlockchainNetwork;
  value: number; // in ETH or native unit
  valueUSD?: number;
  token: string;
  timestamp: number; // epoch ms
  blockNumber: number;
  gasPriceGwei?: number;
  isIncoming?: boolean;
}

export interface WalletStatistics {
  totalTransactions: number;
  incomingTransactions: number;
  outgoingTransactions: number;
  totalVolumeETH: number;
  totalVolumeUSD: number;
  uniqueCounterparties: number;
  firstActivity: string;
  lastActivity: string;
  avgTransactionValue: number;
  maxTransactionValue: number;
  activeDaysSpan: number;
  velocityPerHour: number;
}

export interface Wallet {
  id: string;
  address: string;
  blockchain: BlockchainNetwork;
  statistics: WalletStatistics;
  firstActivity: string;
  lastActivity: string;
  lastAnalyzedAt: string;
  tags?: string[];
  riskScore?: number; // 0 - 100
}

export interface GraphNode {
  id: string;
  label: string;
  address: string;
  type: 'TARGET' | 'INTERMEDIARY' | 'VASP_DEPOSIT' | 'VASP_HOT' | 'VASP_COLD' | 'HIGH_RISK_ENTITY';
  hop: number;
  vaspId?: string;
  vaspName?: string;
  totalVolume: number;
  txCount: number;
  isTarget?: boolean;
  isVASP?: boolean;
  isDemoData?: boolean;
}

export interface GraphEdge {
  id: string;
  source: string;
  target: string;
  txCount: number;
  totalValue: number;
  token: string;
  lastTimestamp: number;
  flowDirection: 'IN' | 'OUT' | 'BIDIRECTIONAL';
}

export interface TransactionGraph {
  nodes: GraphNode[];
  edges: GraphEdge[];
  targetAddress: string;
  totalHops: number;
}

export interface ScoringWeights {
  graphProximity: number;     // default 0.30
  transactionVolume: number;  // default 0.25
  interactionFrequency: number; // default 0.20
  behavioralSimilarity: number; // default 0.15
  temporalPattern: number;    // default 0.10
}

export interface FactorEvidence {
  score: number; // 0.0 - 1.0
  weightedScore: number;
  weight: number;
  metrics: Record<string, any>;
  explanation: string;
}

export interface AttributionEvidence {
  directInteractionsCount: number;
  totalInteractionsCount: number;
  shortestHopDistance: number;
  volumeOverlapETH: number;
  volumeOverlapPercent: number;
  interactionFrequencyScore: number;
  clusterSimilarityScore: number;
  behavioralPatternSummary: string;
  temporalAlignmentWindow: string;
  matchedClusters: Array<{
    clusterAddress: string;
    addressType: AddressType;
    hopDistance: number;
    flowValueETH: number;
    txCount: number;
  }>;
  factors: {
    graphProximity: FactorEvidence;
    transactionVolume: FactorEvidence;
    interactionFrequency: FactorEvidence;
    behavioralSimilarity: FactorEvidence;
    temporalPattern: FactorEvidence;
  };
}

export interface VASPAttributionRank {
  rank: number;
  vasp: VASP;
  score: number; // Percentage (e.g. 84.2%)
  rawScore: number; // 0 - 1
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  evidence: AttributionEvidence;
  isDemoAttribution: boolean;
}

export interface RiskIndicator {
  id: string;
  severity: 'INFO' | 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL';
  title: string;
  description: string;
  category: 'VELOCITY' | 'VOLUME' | 'STRUCTURING' | 'MIXER_PROXIMITY' | 'PEELING_CHAIN' | 'DORMANT_ACTIVATION';
  detectedAt?: string;
  metadata?: Record<string, any>;
}

export interface AttributionResult {
  id: string;
  walletAddress: string;
  blockchain: BlockchainNetwork;
  mostLikelyVasp: VASPAttributionRank;
  rankings: VASPAttributionRank[];
  riskIndicators: RiskIndicator[];
  modelVersion: string;
  scoringWeights: ScoringWeights;
  calculatedAt: string;
  disclaimer: string;
}

export interface InvestigationCase {
  id: string;
  walletAddress: string;
  caseTitle: string;
  investigatorNotes: string;
  status: 'OPEN' | 'IN_REVIEW' | 'COMPLETED' | 'ARCHIVED';
  priority: 'LOW' | 'MEDIUM' | 'HIGH';
  tags: string[];
  reportJson?: string;
  createdAt: string;
  updatedAt: string;
}
