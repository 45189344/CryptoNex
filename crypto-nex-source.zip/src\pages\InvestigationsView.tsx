import React, { useState, useEffect } from 'react';
import { useApp } from '../context/AppContext';
import { apiClient } from '../api/client';
import { InvestigationCase } from '../types';
import { 
  FolderGit2, Plus, FileText, CheckCircle2, 
  Clock, Tag, AlertCircle, Save, ExternalLink 
} from 'lucide-react';

export const InvestigationsView: React.FC = () => {
  const { targetAddress, attribution, wallet, setIsReportModalOpen, runAnalysis, setActiveTab } = useApp();
  const [cases, setCases] = useState<InvestigationCase[]>([]);
  const [loading, setLoading] = useState(true);

  // New Case Form State
  const [caseTitle, setCaseTitle] = useState('');
  const [investigatorNotes, setInvestigatorNotes] = useState('');
  const [priority, setPriority] = useState<'LOW' | 'MEDIUM' | 'HIGH'>('MEDIUM');
  const [tagInput, setTagInput] = useState('VASP-Attribution, SIH-2026');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  useEffect(() => {
    fetchCases();
  }, []);

  const fetchCases = async () => {
    try {
      const data = await apiClient.getInvestigations();
      setCases(data);
    } catch (err) {
      console.error('Failed to load cases:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateCase = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!caseTitle.trim() || !targetAddress) return;

    setIsSaving(true);
    try {
      const tags = tagInput.split(',').map(t => t.trim()).filter(Boolean);
      const newCase = await apiClient.createInvestigation({
        walletAddress: targetAddress,
        caseTitle: caseTitle.trim(),
        investigatorNotes: investigatorNotes.trim(),
        priority,
        tags
      });
      setCases(prev => [newCase, ...prev]);
      setCaseTitle('');
      setInvestigatorNotes('');
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Failed to create case:', err);
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-display text-white flex items-center gap-2">
            <FolderGit2 className="h-6 w-6 text-cyan-400" />
            Investigation Case Management
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Maintain law enforcement case notes, tags, and generate permanent audit dossiers
          </p>
        </div>

        <button
          onClick={() => setIsReportModalOpen(true)}
          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 text-white text-xs font-semibold flex items-center gap-2 shadow-md shadow-cyan-900/30 transition-all self-start sm:self-auto"
        >
          <FileText className="h-4 w-4" />
          <span>Export Current Dossier</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Create Case Form */}
        <div className="lg:col-span-5 p-6 rounded-2xl glass-panel space-y-4">
          <h3 className="text-sm font-semibold text-slate-200 font-display flex items-center gap-2">
            <Plus className="h-4 w-4 text-cyan-400" />
            Open New Case Dossier
          </h3>

          <form onSubmit={handleCreateCase} className="space-y-3.5 text-xs font-mono">
            <div>
              <label className="text-slate-400 block mb-1">Target Address</label>
              <input
                type="text"
                value={targetAddress}
                readOnly
                className="w-full p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-cyan-300 truncate"
              />
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Case Title / Reference *</label>
              <input
                type="text"
                value={caseTitle}
                onChange={(e) => setCaseTitle(e.target.value)}
                placeholder="e.g. Operation Sovereign Nexus - Wallet Tracing"
                required
                className="w-full p-2.5 rounded-xl glass-input text-slate-100 placeholder-slate-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">Priority</label>
                <select
                  value={priority}
                  onChange={(e) => setPriority(e.target.value as any)}
                  className="w-full p-2.5 rounded-xl bg-slate-900 border border-slate-700 text-slate-200"
                >
                  <option value="LOW">LOW</option>
                  <option value="MEDIUM">MEDIUM</option>
                  <option value="HIGH">HIGH</option>
                </select>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Tags (Comma-separated)</label>
                <input
                  type="text"
                  value={tagInput}
                  onChange={(e) => setTagInput(e.target.value)}
                  className="w-full p-2.5 rounded-xl glass-input text-slate-100"
                />
              </div>
            </div>

            <div>
              <label className="text-slate-400 block mb-1">Investigator Observations & Hypotheses</label>
              <textarea
                value={investigatorNotes}
                onChange={(e) => setInvestigatorNotes(e.target.value)}
                rows={4}
                placeholder="Enter forensic notes regarding multi-hop routing, exchange consolidation patterns, and counterparty relationships..."
                className="w-full p-2.5 rounded-xl glass-input text-slate-100 placeholder-slate-500 leading-relaxed"
              />
            </div>

            <button
              type="submit"
              disabled={isSaving || !caseTitle.trim()}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-bold text-xs flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50 cursor-pointer"
            >
              <Save className="h-4 w-4" />
              <span>{isSaving ? 'Saving Case...' : 'Save Investigation Case'}</span>
            </button>

            {saveSuccess && (
              <div className="p-2.5 rounded-lg bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-center flex items-center justify-center gap-1.5">
                <CheckCircle2 className="h-3.5 w-3.5" />
                <span>Case Dossier saved successfully!</span>
              </div>
            )}
          </form>
        </div>

        {/* Existing Case Dossiers List */}
        <div className="lg:col-span-7 p-6 rounded-2xl glass-panel space-y-4">
          <h3 className="text-sm font-semibold text-slate-200 font-display flex items-center gap-2">
            <FolderGit2 className="h-4 w-4 text-emerald-400" />
            Active Investigation Case Registry ({cases.length})
          </h3>

          {loading ? (
            <div className="p-8 text-center text-slate-500 text-xs font-mono">Loading cases...</div>
          ) : cases.length === 0 ? (
            <div className="p-8 rounded-xl bg-slate-900/40 text-center text-slate-500 text-xs font-mono">
              No saved cases yet. Create your first case on the left.
            </div>
          ) : (
            <div className="space-y-3">
              {cases.map((c) => (
                <div key={c.id} className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 hover:border-slate-700 transition-colors">
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-slate-100 text-xs">{c.caseTitle}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded font-semibold ${
                      c.priority === 'HIGH' ? 'bg-rose-500/20 text-rose-300' : 'bg-slate-800 text-slate-300'
                    }`}>
                      {c.priority} Priority
                    </span>
                  </div>

                  <div className="text-[11px] font-mono text-cyan-400 truncate">
                    Target: {c.walletAddress}
                  </div>

                  {c.investigatorNotes && (
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed">
                      {c.investigatorNotes}
                    </p>
                  )}

                  <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[11px] font-mono text-slate-500">
                    <span>{new Date(c.createdAt).toLocaleDateString()}</span>
                    <button
                      onClick={() => {
                        runAnalysis(c.walletAddress);
                        setActiveTab('overview');
                      }}
                      className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                    >
                      <span>Load Analysis</span>
                      <ExternalLink className="h-3 w-3" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
