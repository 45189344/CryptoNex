import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  Wallet as WalletIcon, Copy, ExternalLink, ArrowDownLeft, 
  ArrowUpRight, Users, Activity, Clock, ShieldAlert, CheckCircle2, ArrowRight 
} from 'lucide-react';
import { ResponsiveContainer, PieChart, Pie, Cell, Tooltip } from 'recharts';

export const WalletOverview: React.FC = () => {
  const { wallet, targetAddress, setActiveTab } = useApp();
  const [copied, setCopied] = useState(false);

  if (!wallet) {
    return (
      <div className="p-8 rounded-2xl glass-panel text-center text-slate-400">
        <WalletIcon className="h-10 w-10 mx-auto text-slate-600 mb-2" />
        <p className="text-sm">No wallet loaded. Please perform an analysis first.</p>
      </div>
    );
  }

  const { statistics } = wallet;

  const handleCopy = () => {
    navigator.clipboard.writeText(wallet.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const flowData = [
    { name: 'Incoming Volume', value: statistics.incomingTransactions, color: '#10b981' },
    { name: 'Outgoing Volume', value: statistics.outgoingTransactions, color: '#06b6d4' },
  ];

  return (
    <div className="space-y-6">
      {/* Wallet Identity Banner */}
      <div className="p-6 rounded-2xl glass-panel space-y-4">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 font-bold uppercase">
                {wallet.blockchain} EVM TARGET
              </span>
              <span className="text-xs text-slate-400">Indexed & Verified</span>
            </div>
            <div className="flex items-center gap-2">
              <h2 className="font-mono text-base sm:text-xl font-bold text-slate-100 break-all">
                {wallet.address}
              </h2>
              <button
                onClick={handleCopy}
                className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs flex items-center gap-1 shrink-0 border border-slate-700 transition-colors"
                title="Copy Address"
              >
                <Copy className="h-3.5 w-3.5" />
                <span>{copied ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Risk Rating Badge */}
          <div className="flex items-center gap-4 bg-slate-900/80 p-3 rounded-xl border border-slate-800 self-start lg:self-auto">
            <div>
              <span className="text-[10px] font-mono text-slate-400 uppercase block">Behavioral Anomaly Index</span>
              <span className="text-xl font-bold font-mono text-cyan-300">
                {wallet.riskScore || 25} / 100
              </span>
            </div>
            <div className="h-8 w-[1px] bg-slate-800" />
            <span className="text-xs font-mono text-slate-400">
              {(wallet.riskScore || 25) > 60 ? '⚡ High Velocity' : '✅ Standard Activity'}
            </span>
          </div>
        </div>
      </div>

      {/* Forensic KPI Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Volume */}
        <div className="p-4 rounded-2xl glass-panel space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase text-slate-400">
            <span>Aggregate Volume</span>
            <Activity className="h-4 w-4 text-cyan-400" />
          </div>
          <div className="text-xl font-bold font-mono text-cyan-300">
            {statistics.totalVolumeETH} ETH
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            ~${statistics.totalVolumeUSD.toLocaleString()} USD
          </div>
        </div>

        {/* Transactions Breakdown */}
        <div className="p-4 rounded-2xl glass-panel space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase text-slate-400">
            <span>Transaction Count</span>
            <Users className="h-4 w-4 text-emerald-400" />
          </div>
          <div className="text-xl font-bold font-mono text-emerald-300">
            {statistics.totalTransactions} TXs
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-2">
            <span className="text-emerald-400">↓ {statistics.incomingTransactions} In</span>
            <span className="text-cyan-400">↑ {statistics.outgoingTransactions} Out</span>
          </div>
        </div>

        {/* Unique Counterparties */}
        <div className="p-4 rounded-2xl glass-panel space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase text-slate-400">
            <span>Counterparties</span>
            <Users className="h-4 w-4 text-indigo-400" />
          </div>
          <div className="text-xl font-bold font-mono text-indigo-300">
            {statistics.uniqueCounterparties} Wallets
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            Direct 1-Hop Peers
          </div>
        </div>

        {/* Velocity & Span */}
        <div className="p-4 rounded-2xl glass-panel space-y-1.5">
          <div className="flex items-center justify-between text-[11px] font-mono uppercase text-slate-400">
            <span>Velocity</span>
            <Clock className="h-4 w-4 text-amber-400" />
          </div>
          <div className="text-xl font-bold font-mono text-amber-300">
            {statistics.velocityPerHour} tx/hr
          </div>
          <div className="text-[11px] font-mono text-slate-400">
            Span: {statistics.activeDaysSpan} Active Day(s)
          </div>
        </div>
      </div>

      {/* Deep Dive Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Activity Timeline Card */}
        <div className="lg:col-span-7 p-6 rounded-2xl glass-panel space-y-4">
          <h3 className="text-sm font-semibold text-slate-200 font-display flex items-center gap-2">
            <Clock className="h-4 w-4 text-cyan-400" />
            Activity Span & Execution Timelines
          </h3>

          <div className="space-y-3 font-mono text-xs">
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">First Recorded On-Chain Activity:</span>
              <span className="font-semibold text-slate-200">{new Date(statistics.firstActivity).toLocaleString()}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Most Recent Transaction:</span>
              <span className="font-semibold text-slate-200">{new Date(statistics.lastActivity).toLocaleString()}</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Average Transaction Ticket Size:</span>
              <span className="font-semibold text-cyan-300">{statistics.avgTransactionValue} ETH</span>
            </div>

            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
              <span className="text-slate-400">Peak Single Transaction Value:</span>
              <span className="font-semibold text-emerald-300">{statistics.maxTransactionValue} ETH</span>
            </div>
          </div>
        </div>

        {/* Flow Distribution Donut Chart */}
        <div className="lg:col-span-5 p-6 rounded-2xl glass-panel space-y-4 flex flex-col justify-between">
          <h3 className="text-sm font-semibold text-slate-200 font-display">
            Inflow vs Outflow Ratio
          </h3>

          <div className="h-44 w-full flex items-center justify-center">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={flowData}
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={70}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {flowData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center justify-around text-xs font-mono pt-2 border-t border-slate-800">
            <div className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500" />
              <span className="text-slate-300">Inbound ({statistics.incomingTransactions})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-cyan-500" />
              <span className="text-slate-300">Outbound ({statistics.outgoingTransactions})</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
