import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  ArrowLeftRight, Search, Filter, ArrowDownLeft, 
  ArrowUpRight, Copy, ExternalLink, ShieldCheck 
} from 'lucide-react';

export const TransactionsView: React.FC = () => {
  const { transactions, wallet } = useApp();
  const [searchTerm, setSearchTerm] = useState('');
  const [directionFilter, setDirectionFilter] = useState<'ALL' | 'IN' | 'OUT'>('ALL');
  const [copiedHash, setCopiedHash] = useState<string | null>(null);

  if (!wallet || transactions.length === 0) {
    return (
      <div className="p-8 rounded-2xl glass-panel text-center text-slate-400">
        <ArrowLeftRight className="h-10 w-10 mx-auto text-slate-600 mb-2" />
        <p className="text-sm">No transactions loaded. Run a wallet analysis to populate ledger.</p>
      </div>
    );
  }

  const handleCopy = (hash: string) => {
    navigator.clipboard.writeText(hash);
    setCopiedHash(hash);
    setTimeout(() => setCopiedHash(null), 2000);
  };

  const filteredTxs = transactions.filter((tx) => {
    const isInc = tx.toAddress.toLowerCase() === wallet.address.toLowerCase();
    if (directionFilter === 'IN' && !isInc) return false;
    if (directionFilter === 'OUT' && isInc) return false;

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      return (
        tx.txHash.toLowerCase().includes(term) ||
        tx.fromAddress.toLowerCase().includes(term) ||
        tx.toAddress.toLowerCase().includes(term)
      );
    }
    return true;
  });

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold font-display text-white flex items-center gap-2">
            <ArrowLeftRight className="h-6 w-6 text-cyan-400" />
            On-Chain Transaction Ledger
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Displaying {filteredTxs.length} of {transactions.length} indexed transactions for subject wallet
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex items-center gap-2">
          <div className="flex bg-slate-900 border border-slate-700 rounded-xl p-1 text-xs font-mono">
            <button
              onClick={() => setDirectionFilter('ALL')}
              className={`px-3 py-1 rounded-lg ${directionFilter === 'ALL' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400'}`}
            >
              All ({transactions.length})
            </button>
            <button
              onClick={() => setDirectionFilter('IN')}
              className={`px-3 py-1 rounded-lg ${directionFilter === 'IN' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400'}`}
            >
              Inbound
            </button>
            <button
              onClick={() => setDirectionFilter('OUT')}
              className={`px-3 py-1 rounded-lg ${directionFilter === 'OUT' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400'}`}
            >
              Outbound
            </button>
          </div>
        </div>
      </div>

      {/* Search Input */}
      <div className="relative">
        <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
          <Search className="h-4 w-4" />
        </div>
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Filter by Transaction Hash or Counterparty Address..."
          className="w-full pl-10 pr-4 py-2.5 rounded-xl glass-input text-slate-100 placeholder-slate-500 font-mono text-xs"
        />
      </div>

      {/* Transactions Table */}
      <div className="rounded-2xl glass-panel overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-900/80 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="p-3.5">Direction</th>
                <th className="p-3.5">Tx Hash</th>
                <th className="p-3.5">From Address</th>
                <th className="p-3.5">To Address</th>
                <th className="p-3.5">Value (ETH)</th>
                <th className="p-3.5">Block / Gas</th>
                <th className="p-3.5">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filteredTxs.map((tx) => {
                const isIncoming = tx.toAddress.toLowerCase() === wallet.address.toLowerCase();
                return (
                  <tr key={tx.id} className="hover:bg-slate-900/40 transition-colors">
                    {/* Direction Badge */}
                    <td className="p-3.5">
                      {isIncoming ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 text-[10px] font-semibold">
                          <ArrowDownLeft className="h-3 w-3" /> IN
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 text-[10px] font-semibold">
                          <ArrowUpRight className="h-3 w-3" /> OUT
                        </span>
                      )}
                    </td>

                    {/* Hash */}
                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5 text-cyan-300">
                        <span>{tx.txHash.slice(0, 10)}...{tx.txHash.slice(-6)}</span>
                        <button
                          onClick={() => handleCopy(tx.txHash)}
                          className="text-slate-500 hover:text-slate-300"
                          title="Copy Tx Hash"
                        >
                          <Copy className="h-3 w-3" />
                        </button>
                      </div>
                    </td>

                    {/* From */}
                    <td className="p-3.5">
                      <span className={tx.fromAddress.toLowerCase() === wallet.address.toLowerCase() ? 'text-amber-300 font-bold' : 'text-slate-300'}>
                        {tx.fromAddress.slice(0, 8)}...{tx.fromAddress.slice(-6)}
                      </span>
                    </td>

                    {/* To */}
                    <td className="p-3.5">
                      <span className={tx.toAddress.toLowerCase() === wallet.address.toLowerCase() ? 'text-amber-300 font-bold' : 'text-slate-300'}>
                        {tx.toAddress ? `${tx.toAddress.slice(0, 8)}...${tx.toAddress.slice(-6)}` : 'Contract Creation'}
                      </span>
                    </td>

                    {/* Value */}
                    <td className="p-3.5">
                      <span className="font-bold text-slate-100">{tx.value.toFixed(4)} {tx.token}</span>
                      <span className="block text-[10px] text-slate-500">~${(tx.value * 3450).toFixed(2)} USD</span>
                    </td>

                    {/* Block / Gas */}
                    <td className="p-3.5 text-slate-400">
                      <div>#{tx.blockNumber}</div>
                      <div className="text-[10px] text-slate-500">{tx.gasPriceGwei || 20} Gwei</div>
                    </td>

                    {/* Timestamp */}
                    <td className="p-3.5 text-slate-400 text-[11px]">
                      {new Date(tx.timestamp).toLocaleString()}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
