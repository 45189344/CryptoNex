import React from 'react';
import { useApp } from '../context/AppContext';
import { WalletSearch } from '../components/WalletSearch';
import { VaspAttributionCard } from '../components/VaspAttributionCard';
import { 
  Search, ShieldCheck, Cpu, Network, Target, 
  CheckCircle2, ArrowRight, Sparkles 
} from 'lucide-react';

export const AnalyzeWallet: React.FC = () => {
  const { isAnalyzing, analysisStep, attribution, setActiveTab } = useApp();

  const steps = [
    { num: 1, label: 'Address Validation & Checksum Verification', icon: ShieldCheck },
    { num: 2, label: 'On-Chain Ingestion & Counterparty Extraction', icon: Search },
    { num: 3, label: 'Multi-Hop Transaction Graph Construction', icon: Network },
    { num: 4, label: 'VASP Cluster Matching & ML Ingestion Signature', icon: Cpu },
    { num: 5, label: '5-Factor Weighted Probabilistic Scoring', icon: Target },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold font-display text-white">
          Deep Wallet Analysis & Attribution Pipeline
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Execute automated multi-hop traversal and behavioral cluster matching against known VASP registries
        </p>
      </div>

      <WalletSearch />

      {/* Pipeline Execution Animation */}
      {isAnalyzing && (
        <div className="p-8 rounded-2xl glass-panel space-y-6">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono uppercase text-cyan-400 font-bold flex items-center gap-2">
              <Sparkles className="h-4 w-4 animate-spin" />
              Automated Pipeline Execution in Progress
            </span>
            <span className="text-xs font-mono text-slate-400">
              Step {analysisStep} of 5
            </span>
          </div>

          <div className="space-y-3">
            {steps.map((s) => {
              const Icon = s.icon;
              const isDone = analysisStep > s.num;
              const isCurrent = analysisStep === s.num;
              return (
                <div
                  key={s.num}
                  className={`p-3.5 rounded-xl border flex items-center justify-between transition-all ${
                    isDone
                      ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                      : isCurrent
                        ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300 shadow-md shadow-cyan-500/10'
                        : 'bg-slate-900/40 border-slate-800 text-slate-500'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`h-7 w-7 rounded-lg flex items-center justify-center font-mono text-xs font-bold ${
                      isDone 
                        ? 'bg-emerald-500 text-slate-950' 
                        : isCurrent 
                          ? 'bg-cyan-500 text-slate-950 animate-pulse' 
                          : 'bg-slate-800 text-slate-500'
                    }`}>
                      {isDone ? <CheckCircle2 className="h-4 w-4" /> : s.num}
                    </div>
                    <span className="text-xs font-medium">{s.label}</span>
                  </div>

                  {isCurrent && (
                    <div className="h-4 w-4 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin" />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Results View */}
      {!isAnalyzing && attribution && (
        <div className="space-y-6 animate-in fade-in duration-300">
          <VaspAttributionCard />

          <div className="flex items-center justify-end gap-3">
            <button
              onClick={() => setActiveTab('graph')}
              className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-mono text-slate-200 flex items-center gap-1.5 transition-colors"
            >
              <Network className="h-3.5 w-3.5 text-cyan-400" />
              <span>Explore Graph Visualization</span>
              <ArrowRight className="h-3.5 w-3.5" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
