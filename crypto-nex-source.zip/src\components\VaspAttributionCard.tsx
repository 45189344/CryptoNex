import React from 'react';
import { useApp } from '../context/AppContext';
import { Target, ShieldCheck, AlertTriangle, ArrowRight, ExternalLink, Activity, Info } from 'lucide-react';

export const VaspAttributionCard: React.FC = () => {
  const { attribution, isAnalyzing, setActiveTab } = useApp();

  if (isAnalyzing) {
    return (
      <div className="p-8 rounded-2xl glass-panel flex flex-col items-center justify-center min-h-[320px] text-center">
        <div className="relative mb-4">
          <div className="h-16 w-16 rounded-full border-4 border-cyan-500/20 border-t-cyan-400 animate-spin" />
          <Target className="h-6 w-6 text-cyan-400 absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" />
        </div>
        <h4 className="text-lg font-semibold text-slate-200 mb-1 font-display">
          Computing Multi-Factor VASP Attribution
        </h4>
        <p className="text-xs text-slate-400 max-w-md font-mono">
          Traversing multi-hop graph topology, cluster matching, and calculating weighted behavioral scores...
        </p>
      </div>
    );
  }

  if (!attribution) {
    return (
      <div className="p-8 rounded-2xl glass-panel text-center text-slate-400">
        <Target className="h-10 w-10 mx-auto text-slate-600 mb-2" />
        <p className="text-sm font-medium">No wallet analyzed yet.</p>
        <p className="text-xs text-slate-500 mt-1">Enter a wallet address above to generate probabilistic VASP attribution.</p>
      </div>
    );
  }

  const { mostLikelyVasp, rankings, disclaimer } = attribution;

  return (
    <div className="space-y-4">
      {/* Hero: Most Likely Associated VASP */}
      <div className="p-6 rounded-2xl glass-panel relative overflow-hidden border-cyan-500/30 shadow-xl shadow-cyan-950/30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-bl from-cyan-500/15 via-indigo-500/10 to-transparent rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-6 relative z-10">
          {/* VASP Primary Entity */}
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono uppercase tracking-wider text-cyan-400 font-semibold flex items-center gap-1.5">
                <Target className="h-4 w-4" />
                Most Likely Associated VASP:
              </span>
              {mostLikelyVasp.isDemoAttribution ? (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-500/15 text-amber-300 border border-amber-500/30 font-semibold">
                  DEMO SIMULATION CLUSTER
                </span>
              ) : (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-300 border border-emerald-500/30 font-semibold flex items-center gap-1">
                  <ShieldCheck className="h-3 w-3" /> VERIFIED PUBLIC CLUSTER
                </span>
              )}
            </div>

            <div className="flex items-baseline gap-4">
              <h2 className="text-3xl sm:text-4xl font-extrabold font-display tracking-tight text-white">
                {mostLikelyVasp.vasp.name}
              </h2>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 border border-slate-700">
                  {mostLikelyVasp.vasp.type}
                </span>
                <span className="text-xs font-mono text-slate-400 hidden sm:inline">
                  📍 {mostLikelyVasp.vasp.country}
                </span>
              </div>
            </div>

            <p className="text-xs text-slate-400 max-w-xl leading-relaxed">
              {mostLikelyVasp.vasp.description}
            </p>
          </div>

          {/* Large Attribution Score Circle / Gauge */}
          <div className="flex items-center gap-5 bg-slate-900/80 p-4 rounded-xl border border-slate-800 shrink-0">
            <div className="text-center">
              <div className="text-4xl font-extrabold font-display bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">
                {mostLikelyVasp.score}%
              </div>
              <span className="text-[11px] font-mono text-slate-400">Attribution Probability</span>
            </div>

            <div className="h-10 w-[1px] bg-slate-800" />

            <div className="space-y-1">
              <div className="flex items-center gap-1.5">
                <span className="text-xs text-slate-400">Confidence:</span>
                <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded ${
                  mostLikelyVasp.confidence === 'HIGH'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                    : mostLikelyVasp.confidence === 'MEDIUM'
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'bg-slate-700 text-slate-300'
                }`}>
                  {mostLikelyVasp.confidence}
                </span>
              </div>
              <div className="text-[11px] text-slate-500 font-mono">
                {mostLikelyVasp.evidence.shortestHopDistance === 1 ? 'Direct 1-Hop Ingestion' : `${mostLikelyVasp.evidence.shortestHopDistance}-Hop Topology`}
              </div>
            </div>
          </div>
        </div>

        {/* Quick Highlights Bar */}
        <div className="mt-6 pt-4 border-t border-slate-800/80 grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="bg-slate-900/50 p-2.5 rounded-lg border border-slate-800/60">
            <span className="text-slate-500 block text-[11px]">Direct Interactions:</span>
            <span className="font-mono font-bold text-slate-200">
              {mostLikelyVasp.evidence.directInteractionsCount} txs
            </span>
          </div>
          <div className="bg-slate-900/50 p-2.5 rounded-lg border border-slate-800/60">
            <span className="text-slate-500 block text-[11px]">Volume Overlap:</span>
            <span className="font-mono font-bold text-cyan-300">
              {mostLikelyVasp.evidence.volumeOverlapETH} ETH ({mostLikelyVasp.evidence.volumeOverlapPercent}%)
            </span>
          </div>
          <div className="bg-slate-900/50 p-2.5 rounded-lg border border-slate-800/60">
            <span className="text-slate-500 block text-[11px]">Shortest Hop Distance:</span>
            <span className="font-mono font-bold text-emerald-300">
              {mostLikelyVasp.evidence.shortestHopDistance} Hop{mostLikelyVasp.evidence.shortestHopDistance > 1 ? 's' : ''}
            </span>
          </div>
          <div className="bg-slate-900/50 p-2.5 rounded-lg border border-slate-800/60">
            <span className="text-slate-500 block text-[11px]">Matched Cluster Nodes:</span>
            <span className="font-mono font-bold text-indigo-300">
              {mostLikelyVasp.evidence.matchedClusters.length} addresses
            </span>
          </div>
        </div>
      </div>

      {/* Comparative VASP Leaderboard */}
      <div className="p-6 rounded-2xl glass-panel space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-sm font-semibold text-slate-200 font-display flex items-center gap-2">
              <Activity className="h-4 w-4 text-cyan-400" />
              Candidate VASP Ranking Leaderboard
            </h3>
            <p className="text-xs text-slate-400">
              Comparative probabilistic distribution across all analyzed candidate clusters
            </p>
          </div>
          <button
            onClick={() => setActiveTab('evidence')}
            className="text-xs font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
          >
            <span>Inspect 5-Factor Matrix</span>
            <ArrowRight className="h-3.5 w-3.5" />
          </button>
        </div>

        <div className="space-y-3">
          {rankings.map((item) => (
            <div
              key={item.vasp.id}
              className={`p-3.5 rounded-xl border transition-all ${
                item.rank === 1
                  ? 'bg-slate-900/90 border-cyan-500/40 shadow-sm shadow-cyan-500/10'
                  : 'bg-slate-900/40 border-slate-800 hover:border-slate-700'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-3">
                  <span className={`h-6 w-6 rounded-full flex items-center justify-center font-mono font-bold text-xs ${
                    item.rank === 1 ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'
                  }`}>
                    #{item.rank}
                  </span>
                  <div>
                    <span className="font-semibold text-slate-200 text-sm mr-2">{item.vasp.name}</span>
                    <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
                      {item.vasp.type}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-display font-bold text-lg text-slate-100">{item.score}%</span>
                  <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded ${
                    item.confidence === 'HIGH' 
                      ? 'bg-emerald-500/20 text-emerald-300' 
                      : item.confidence === 'MEDIUM' 
                        ? 'bg-amber-500/20 text-amber-300' 
                        : 'bg-slate-800 text-slate-400'
                  }`}>
                    {item.confidence}
                  </span>
                </div>
              </div>

              {/* Progress meter */}
              <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all duration-700 ${
                    item.rank === 1 
                      ? 'bg-gradient-to-r from-cyan-500 to-emerald-400' 
                      : item.rank === 2 
                        ? 'bg-indigo-500' 
                        : 'bg-slate-600'
                  }`}
                  style={{ width: `${Math.max(4, item.score)}%` }}
                />
              </div>

              <div className="flex items-center justify-between mt-2 text-[11px] font-mono text-slate-400">
                <span>Hop Proximity: {item.evidence.shortestHopDistance === 0 ? 'No direct path' : `${item.evidence.shortestHopDistance} hop(s)`}</span>
                <span>Volume Overlap: {item.evidence.volumeOverlapETH} ETH</span>
                <span>Interactions: {item.evidence.totalInteractionsCount} txs</span>
              </div>
            </div>
          ))}
        </div>

        {/* Legal Disclaimer Pill */}
        <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 text-[11px] text-slate-400 flex items-start gap-2">
          <Info className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            {disclaimer}
          </p>
        </div>
      </div>
    </div>
  );
};
