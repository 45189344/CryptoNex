import React from 'react';
import { useApp } from '../context/AppContext';
import { X, Copy, ExternalLink, ShieldCheck, AlertTriangle, Target, Network } from 'lucide-react';

export const NodeDetailModal: React.FC = () => {
  const { inspectedNode, setInspectedNode, runAnalysis, setActiveTab } = useApp();
  const [copied, setCopied] = React.useState(false);

  if (!inspectedNode) return null;

  const handleCopy = () => {
    navigator.clipboard.writeText(inspectedNode.address);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleAnalyzeAsTarget = () => {
    const addr = inspectedNode.address;
    setInspectedNode(null);
    runAnalysis(addr);
    setActiveTab('overview');
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-lg rounded-2xl glass-panel border-cyan-500/40 p-6 space-y-5 shadow-2xl relative animate-in fade-in zoom-in duration-200">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center gap-2">
            <Network className="h-5 w-5 text-cyan-400" />
            <h3 className="text-base font-bold font-display text-slate-100">Node Forensics & Identity</h3>
          </div>
          <button
            onClick={() => setInspectedNode(null)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Address & Copy */}
        <div className="space-y-1.5">
          <label className="text-[11px] font-mono uppercase text-slate-400">On-Chain Address</label>
          <div className="flex items-center gap-2 p-2.5 rounded-xl bg-slate-950 border border-slate-800">
            <span className="font-mono text-xs text-cyan-300 truncate flex-1">{inspectedNode.address}</span>
            <button
              onClick={handleCopy}
              className="p-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs flex items-center gap-1 transition-colors"
              title="Copy Address"
            >
              <Copy className="h-3.5 w-3.5" />
              <span>{copied ? 'Copied' : 'Copy'}</span>
            </button>
          </div>
        </div>

        {/* Node Metrics Grid */}
        <div className="grid grid-cols-2 gap-3 text-xs font-mono">
          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-500 text-[10px] block uppercase">Hop Distance</span>
            <span className="font-bold text-emerald-400 text-sm">{inspectedNode.hop} Hop(s) from Target</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-500 text-[10px] block uppercase">Topology Role</span>
            <span className="font-bold text-slate-200 text-sm">{inspectedNode.type}</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-500 text-[10px] block uppercase">Total Transacted Flow</span>
            <span className="font-bold text-cyan-300 text-sm">{inspectedNode.totalVolume.toFixed(4)} ETH</span>
          </div>

          <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800">
            <span className="text-slate-500 text-[10px] block uppercase">Interactions Count</span>
            <span className="font-bold text-slate-200 text-sm">{inspectedNode.txCount} txs</span>
          </div>
        </div>

        {/* VASP Details if matched */}
        {inspectedNode.isVASP && (
          <div className="p-4 rounded-xl bg-emerald-500/10 border border-emerald-500/30 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-300 flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4" />
                VASP Entity: {inspectedNode.vaspName}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300">
                {inspectedNode.isDemoData ? 'DEMO SIMULATION' : 'VERIFIED CLUSTER'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              This address cluster is mapped to {inspectedNode.vaspName} centralized custody infrastructure.
            </p>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-slate-800">
          <button
            onClick={() => setInspectedNode(null)}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 text-xs font-medium transition-colors"
          >
            Close
          </button>
          <button
            onClick={handleAnalyzeAsTarget}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-semibold shadow-md shadow-cyan-900/30 transition-all flex items-center gap-1.5"
          >
            <Target className="h-3.5 w-3.5" />
            <span>Analyze as New Target</span>
          </button>
        </div>
      </div>
    </div>
  );
};
