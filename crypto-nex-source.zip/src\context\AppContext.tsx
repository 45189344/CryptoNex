import React, { createContext, useContext, useState, useEffect } from 'react';
import { 
  Wallet, Transaction, TransactionGraph, AttributionResult, 
  PresetWallet, ScoringWeights, BlockchainNetwork, GraphNode 
} from '../types';
import { apiClient } from '../api/client';

export type ActiveTab = 
  | 'dashboard' 
  | 'analyze' 
  | 'overview' 
  | 'transactions' 
  | 'graph' 
  | 'attribution' 
  | 'evidence' 
  | 'investigations' 
  | 'vasp-registry' 
  | 'settings';

interface AppContextType {
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  targetAddress: string;
  setTargetAddress: (addr: string) => void;
  selectedNetwork: BlockchainNetwork;
  setSelectedNetwork: (net: BlockchainNetwork) => void;
  maxHops: number;
  setMaxHops: (hops: number) => void;
  
  // Analysis Data
  wallet: Wallet | null;
  transactions: Transaction[];
  graph: TransactionGraph | null;
  attribution: AttributionResult | null;
  presets: PresetWallet[];
  weights: ScoringWeights;
  
  // Loading & State
  isAnalyzing: boolean;
  analysisStep: number;
  analysisError: string | null;
  
  // Actions
  runAnalysis: (address?: string, hops?: number) => Promise<void>;
  loadPreset: (preset: PresetWallet) => void;
  updateWeights: (newWeights: Partial<ScoringWeights>) => Promise<void>;
  
  // Selected Graph Node for Modal Inspection
  inspectedNode: GraphNode | null;
  setInspectedNode: (node: GraphNode | null) => void;
  
  // Report Modal
  isReportModalOpen: boolean;
  setIsReportModalOpen: (open: boolean) => void;
}

const defaultWeights: ScoringWeights = {
  graphProximity: 0.30,
  transactionVolume: 0.25,
  interactionFrequency: 0.20,
  behavioralSimilarity: 0.15,
  temporalPattern: 0.10,
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [targetAddress, setTargetAddress] = useState<string>('0x71c8413158b44ff3263df3bc8d5fa3f05d5d8361');
  const [selectedNetwork, setSelectedNetwork] = useState<BlockchainNetwork>('ethereum');
  const [maxHops, setMaxHops] = useState<number>(2);

  const [wallet, setWallet] = useState<Wallet | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [graph, setGraph] = useState<TransactionGraph | null>(null);
  const [attribution, setAttribution] = useState<AttributionResult | null>(null);
  const [presets, setPresets] = useState<PresetWallet[]>([]);
  const [weights, setWeights] = useState<ScoringWeights>(defaultWeights);

  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisStep, setAnalysisStep] = useState<number>(0);
  const [analysisError, setAnalysisError] = useState<string | null>(null);

  const [inspectedNode, setInspectedNode] = useState<GraphNode | null>(null);
  const [isReportModalOpen, setIsReportModalOpen] = useState<boolean>(false);

  // Initial fetch of presets & weights
  useEffect(() => {
    apiClient.getPresets()
      .then(res => setPresets(res))
      .catch(() => {});

    apiClient.getScoringWeights()
      .then(res => setWeights(res))
      .catch(() => {});

    // Auto-run initial demo address
    runAnalysis('0x71c8413158b44ff3263df3bc8d5fa3f05d5d8361', 2);
  }, []);

  const runAnalysis = async (addressToAnalyze?: string, hopsCount?: number) => {
    const addr = (addressToAnalyze || targetAddress).trim().toLowerCase();
    const hops = hopsCount || maxHops;

    if (!addr || !/^0x[a-fA-F0-9]{40}$/.test(addr)) {
      setAnalysisError('Please enter a valid 42-character EVM hexadecimal address (0x...)');
      return;
    }

    setAnalysisError(null);
    setIsAnalyzing(true);
    setAnalysisStep(1); // Step 1: Validating Address & Ingesting On-Chain TXs

    try {
      await new Promise(r => setTimeout(r, 400));
      setAnalysisStep(2); // Step 2: Mapping Counterparties & Building Graph

      await new Promise(r => setTimeout(r, 450));
      setAnalysisStep(3); // Step 3: Cluster Matching & ML Ingestion Signature

      const result = await apiClient.analyzeWallet(addr, selectedNetwork, hops, weights);

      await new Promise(r => setTimeout(r, 400));
      setAnalysisStep(4); // Step 4: Computing 5-Factor Attribution & Confidence

      setWallet(result.wallet);
      setTransactions(result.transactions);
      setGraph(result.graph);
      setAttribution(result.attribution);
      setTargetAddress(addr);

      await new Promise(r => setTimeout(r, 300));
      setAnalysisStep(5); // Complete
    } catch (err: any) {
      console.error('Analysis error:', err);
      setAnalysisError(err.response?.data?.error || err.message || 'Analysis failed. Please try again.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  const loadPreset = (preset: PresetWallet) => {
    setTargetAddress(preset.address);
    setMaxHops(preset.hopsToVasp || 2);
    runAnalysis(preset.address, preset.hopsToVasp || 2);
    setActiveTab('overview');
  };

  const updateWeights = async (newWeights: Partial<ScoringWeights>) => {
    try {
      const updated = await apiClient.updateScoringWeights(newWeights);
      setWeights(updated);
      // Re-run attribution for current address if loaded
      if (wallet) {
        const res = await apiClient.analyzeWallet(wallet.address, selectedNetwork, maxHops, updated);
        setAttribution(res.attribution);
      }
    } catch (err: any) {
      console.error('Failed to update weights:', err);
    }
  };

  return (
    <AppContext.Provider
      value={{
        activeTab,
        setActiveTab,
        targetAddress,
        setTargetAddress,
        selectedNetwork,
        setSelectedNetwork,
        maxHops,
        setMaxHops,
        wallet,
        transactions,
        graph,
        attribution,
        presets,
        weights,
        isAnalyzing,
        analysisStep,
        analysisError,
        runAnalysis,
        loadPreset,
        updateWeights,
        inspectedNode,
        setInspectedNode,
        isReportModalOpen,
        setIsReportModalOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within an AppProvider');
  return context;
};
