import React from 'react';
import { useApp } from '../context/AppContext';
import { VaspAttributionCard } from '../components/VaspAttributionCard';
import { RiskIndicators } from '../components/RiskIndicators';
import { Target, FileText, ArrowRight } from 'lucide-react';

export const VaspAttributionView: React.FC = () => {
  const { setActiveTab, setIsReportModalOpen } = useApp();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold font-display text-white flex items-center gap-2">
            <Target className="h-6 w-6 text-cyan-400" />
            VASP Attribution & Probability Rankings
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Probabilistic ranking and confidence evaluation against known Virtual Asset Service Providers
          </p>
        </div>

        <button
          onClick={() => setIsReportModalOpen(true)}
          className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-semibold flex items-center gap-2 shadow-md shadow-cyan-900/30 transition-all"
        >
          <FileText className="h-4 w-4" />
          <span>Export Case Dossier</span>
        </button>
      </div>

      <VaspAttributionCard />

      <RiskIndicators />

      <div className="p-6 rounded-2xl glass-panel flex items-center justify-between">
        <div>
          <h4 className="text-sm font-semibold text-slate-200">Want to inspect the underlying mathematical proof?</h4>
          <p className="text-xs text-slate-400 mt-0.5">Explore the 5-factor breakdown (Graph Proximity, Volume, Frequency, Behavioral, Temporal).</p>
        </div>
        <button
          onClick={() => setActiveTab('evidence')}
          className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-mono text-cyan-300 flex items-center gap-1.5 transition-colors"
        >
          <span>Open Evidence Matrix</span>
          <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </div>
  );
};
