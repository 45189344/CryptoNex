import React from 'react';
import { useApp, ActiveTab } from '../context/AppContext';
import { 
  LayoutDashboard, Search, Wallet, ArrowLeftRight, 
  Network, Target, FileCode, FolderGit2, Building2, Sliders,
  ShieldAlert, CheckCircle2, ChevronRight
} from 'lucide-react';

export const Sidebar: React.FC = () => {
  const { activeTab, setActiveTab, targetAddress, attribution, isAnalyzing } = useApp();

  const navItems: { id: ActiveTab; label: string; icon: React.FC<{ className?: string }>; badge?: string }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'analyze', label: 'Analyze Wallet', icon: Search },
    { id: 'overview', label: 'Wallet Overview', icon: Wallet },
    { id: 'transactions', label: 'Transactions Ledger', icon: ArrowLeftRight },
    { id: 'graph', label: 'Transaction Graph', icon: Network, badge: 'Interactive' },
    { id: 'attribution', label: 'VASP Attribution', icon: Target, badge: attribution ? `${attribution.mostLikelyVasp.score}%` : undefined },
    { id: 'evidence', label: 'Evidence & Logic', icon: FileCode },
    { id: 'investigations', label: 'Investigation Cases', icon: FolderGit2 },
    { id: 'vasp-registry', label: 'VASP Registry', icon: Building2 },
    { id: 'settings', label: 'Scoring Weights', icon: Sliders },
  ];

  return (
    <aside className="w-64 border-r border-slate-800/80 bg-slate-950/60 backdrop-blur-xl flex flex-col justify-between p-4 shrink-0 h-[calc(100vh-4rem)] sticky top-16 overflow-y-auto">
      {/* Navigation Links */}
      <div className="space-y-1.5">
        <div className="px-3 py-1 text-[11px] font-mono uppercase tracking-wider text-slate-500">
          Intelligence Modules
        </div>

        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-sm font-medium transition-all ${
                isActive
                  ? 'bg-gradient-to-r from-cyan-500/15 to-indigo-500/15 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-500/10'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60 border border-transparent'
              }`}
            >
              <div className="flex items-center gap-3">
                <Icon className={`h-4 w-4 ${isActive ? 'text-cyan-400' : 'text-slate-500'}`} />
                <span>{item.label}</span>
              </div>
              {item.badge && (
                <span className={`text-[10px] font-mono px-1.5 py-0.5 rounded-full ${
                  isActive 
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40' 
                    : 'bg-slate-800 text-slate-400 border border-slate-700'
                }`}>
                  {item.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Target Active Wallet Card */}
      <div className="pt-4 border-t border-slate-800/80">
        <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
          <div className="flex items-center justify-between text-[11px] text-slate-400 mb-1.5">
            <span className="font-mono uppercase">Active Target</span>
            {isAnalyzing ? (
              <span className="text-amber-400 animate-pulse flex items-center gap-1">
                <span className="h-1.5 w-1.5 rounded-full bg-amber-400" /> Analyzing...
              </span>
            ) : (
              <span className="text-emerald-400 flex items-center gap-1">
                <CheckCircle2 className="h-3 w-3" /> Indexed
              </span>
            )}
          </div>
          <div className="font-mono text-xs text-cyan-300 truncate bg-slate-950 px-2 py-1 rounded border border-slate-800 mb-2">
            {targetAddress ? `${targetAddress.slice(0, 10)}...${targetAddress.slice(-8)}` : 'No wallet selected'}
          </div>
          {attribution && (
            <div className="flex items-center justify-between text-xs pt-1 border-t border-slate-800/60">
              <span className="text-slate-400">Attributed VASP:</span>
              <span className="font-semibold text-emerald-400">
                {attribution.mostLikelyVasp.vasp.name} ({attribution.mostLikelyVasp.score}%)
              </span>
            </div>
          )}
        </div>

        {/* SIH Compliance Disclaimer snippet */}
        <div className="mt-3 px-2 text-[10px] text-slate-500 leading-tight">
          ⚖️ <span className="font-medium text-slate-400">Probabilistic Attribution:</span> Heuristic graph & behavioral profiling. Does not constitute ownership proof.
        </div>
      </div>
    </aside>
  );
};
