import { Pool } from 'pg';
import { config } from '../config';
import { 
  VASP, VASPAddress, Wallet, Transaction, AttributionResult, 
  InvestigationCase, ScoringWeights 
} from '../types';
import { SEED_VASPS, SEED_VASP_ADDRESSES, DEFAULT_SCORING_WEIGHTS } from './seeds';

class DatabaseService {
  private pgPool: Pool | null = null;
  public isPostgresConnected = false;

  // In-Memory Fallback Store (Ensures 100% instant zero-dependency out-of-the-box operation)
  private memoryVasps: Map<string, VASP> = new Map();
  private memoryAddresses: Map<string, VASPAddress> = new Map(); // address -> VASPAddress
  private memoryWallets: Map<string, Wallet> = new Map(); // address -> Wallet
  private memoryTransactions: Map<string, Transaction[]> = new Map(); // address -> Transaction[]
  private memoryAttributions: Map<string, AttributionResult> = new Map(); // address -> AttributionResult
  private memoryInvestigations: Map<string, InvestigationCase> = new Map(); // id -> InvestigationCase
  private activeWeights: ScoringWeights = { ...DEFAULT_SCORING_WEIGHTS };

  constructor() {
    this.initMemoryStore();
    if (config.database.enabled) {
      this.initPostgres();
    }
  }

  private initMemoryStore() {
    console.log('[Database] Initializing In-Memory Relational Engine & Seeds...');
    for (const vasp of SEED_VASPS) {
      this.memoryVasps.set(vasp.id, vasp);
    }
    for (const addr of SEED_VASP_ADDRESSES) {
      this.memoryAddresses.set(addr.address.toLowerCase(), addr);
    }
    console.log(`[Database] Loaded ${this.memoryVasps.size} VASPs and ${this.memoryAddresses.size} address clusters.`);
  }

  private async initPostgres() {
    try {
      this.pgPool = new Pool({
        host: config.database.host,
        port: config.database.port,
        user: config.database.user,
        password: config.database.password,
        database: config.database.name,
        connectionTimeoutMillis: 3000,
      });

      const client = await this.pgPool.connect();
      this.isPostgresConnected = true;
      client.release();
      console.log('[Database] Connected successfully to PostgreSQL database.');
      await this.syncSeedsToPostgres();
    } catch (err: any) {
      console.warn(`[Database] PostgreSQL connection failed (${err.message}). Using In-Memory Store.`);
      this.isPostgresConnected = false;
    }
  }

  private async syncSeedsToPostgres() {
    if (!this.pgPool || !this.isPostgresConnected) return;
    try {
      for (const vasp of SEED_VASPS) {
        await this.pgPool.query(
          `INSERT INTO vasps (id, name, type, country, website, risk_rating, description, is_verified)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
           ON CONFLICT (id) DO UPDATE SET name = $2, type = $3, risk_rating = $6`,
          [vasp.id, vasp.name, vasp.type, vasp.country, vasp.website, vasp.riskRating, vasp.description, vasp.isVerified]
        );
      }
      for (const addr of SEED_VASP_ADDRESSES) {
        await this.pgPool.query(
          `INSERT INTO vasp_addresses (id, vasp_id, blockchain, address, address_type, source, source_type, confidence, verification_status, last_verified_date, is_demo_data)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
           ON CONFLICT (blockchain, address) DO NOTHING`,
          [addr.id, addr.vaspId, addr.blockchain, addr.address.toLowerCase(), addr.addressType, addr.source, addr.sourceType, addr.confidence, addr.verificationStatus, addr.lastVerifiedDate, addr.isDemoData]
        );
      }
    } catch (err: any) {
      console.error('[Database] Seed sync to Postgres failed:', err.message);
    }
  }

  // --- VASP Queries ---
  async getVasps(): Promise<VASP[]> {
    return Array.from(this.memoryVasps.values());
  }

  async getVaspById(id: string): Promise<VASP | undefined> {
    return this.memoryVasps.get(id);
  }

  async getVaspAddresses(): Promise<VASPAddress[]> {
    return Array.from(this.memoryAddresses.values());
  }

  async getVaspByAddress(address: string): Promise<{ vasp: VASP; vaspAddress: VASPAddress } | null> {
    const normalized = address.toLowerCase();
    const vaspAddr = this.memoryAddresses.get(normalized);
    if (!vaspAddr) return null;
    const vasp = this.memoryVasps.get(vaspAddr.vaspId);
    if (!vasp) return null;
    return { vasp, vaspAddress: vaspAddr };
  }

  // --- Wallet Queries ---
  async getWallet(address: string): Promise<Wallet | null> {
    return this.memoryWallets.get(address.toLowerCase()) || null;
  }

  async saveWallet(wallet: Wallet): Promise<void> {
    this.memoryWallets.set(wallet.address.toLowerCase(), wallet);
  }

  // --- Transaction Queries ---
  async getTransactions(address: string): Promise<Transaction[]> {
    return this.memoryTransactions.get(address.toLowerCase()) || [];
  }

  async saveTransactions(address: string, txs: Transaction[]): Promise<void> {
    this.memoryTransactions.set(address.toLowerCase(), txs);
  }

  // --- Attribution Queries ---
  async getAttribution(address: string): Promise<AttributionResult | null> {
    return this.memoryAttributions.get(address.toLowerCase()) || null;
  }

  async saveAttribution(result: AttributionResult): Promise<void> {
    this.memoryAttributions.set(result.walletAddress.toLowerCase(), result);
  }

  // --- Investigation Cases ---
  async getInvestigations(): Promise<InvestigationCase[]> {
    return Array.from(this.memoryInvestigations.values()).sort(
      (a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()
    );
  }

  async getInvestigation(id: string): Promise<InvestigationCase | null> {
    return this.memoryInvestigations.get(id) || null;
  }

  async saveInvestigation(investigation: InvestigationCase): Promise<void> {
    this.memoryInvestigations.set(investigation.id, investigation);
  }

  async updateInvestigation(id: string, updates: Partial<InvestigationCase>): Promise<InvestigationCase | null> {
    const existing = this.memoryInvestigations.get(id);
    if (!existing) return null;
    const updated: InvestigationCase = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString()
    };
    this.memoryInvestigations.set(id, updated);
    return updated;
  }

  // --- Scoring Weights ---
  getScoringWeights(): ScoringWeights {
    return { ...this.activeWeights };
  }

  setScoringWeights(weights: Partial<ScoringWeights>): ScoringWeights {
    this.activeWeights = {
      ...this.activeWeights,
      ...weights
    };
    return { ...this.activeWeights };
  }
}

export const db = new DatabaseService();
