import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Search, Sparkles, AlertCircle, ArrowRight, ShieldCheck, Layers } from 'lucide-react';
import { PresetWallet } from '../types';

export const WalletSearch: React.FC<{ compact?: boolean }> = ({ compact = false }) => {
  const { 
    targetAddress, setTargetAddress, maxHops, setMaxHops, 
    runAnalysis, isAnalyzing, presets, loadPreset, analysisError 
  } = useApp();

  const [inputVal, setInputVal] = useState<string>(targetAddress);
  const isValidAddress = /^0x[a-fA-F0-9]{40}$/.test(inputVal.trim());

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (isValidAddress) {
      setTargetAddress(inputVal.trim());
      runAnalysis(inputVal.trim(), maxHops);
    }
  };

  return (
    <div className={`w-full ${compact ? '' : 'p-6 rounded-2xl glass-panel relative overflow-hidden'}`}>
      {!compact && (
        <div className="absolute -top-24 -right-24 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
      )}

      {/* Main Search Bar */}
      <form onSubmit={handleSearch} className="space-y-4 relative z-10">
        <div className="flex flex-col md:flex-row items-stretch md:items-center gap-3">
          {/* Address Input Container */}
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
              <Search className="h-4 w-4 text-cyan-400" />
            </div>
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Enter EVM Wallet Address (0x...)"
              className="w-full pl-10 pr-10 py-3 rounded-xl glass-input text-slate-100 placeholder-slate-500 font-mono text-sm transition-all focus:ring-2 focus:ring-cyan-500/40"
            />
            {inputVal && (
              <div className="absolute inset-y-0 right-0 pr-3.5 flex items-center">
                {isValidAddress ? (
                  <span title="Valid EVM Address">
                    <ShieldCheck className="h-4 w-4 text-emerald-400" />
                  </span>
                ) : (
                  <span title="Invalid Address Format">
                    <AlertCircle className="h-4 w-4 text-amber-400" />
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Hop Depth Selector */}
          <div className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-900/80 border border-slate-700/80 shrink-0">
            <Layers className="h-4 w-4 text-slate-400" />
            <span className="text-xs text-slate-300 font-mono">Depth:</span>
            <div className="flex gap-1">
              {[1, 2, 3].map((hop) => (
                <button
                  type="button"
                  key={hop}
                  onClick={() => setMaxHops(hop)}
                  className={`px-2.5 py-1 text-xs rounded-lg font-mono font-medium transition-all ${
                    maxHops === hop
                      ? 'bg-cyan-500 text-slate-950 shadow-sm shadow-cyan-500/50'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                  }`}
                >
                  {hop} Hop{hop > 1 ? 's' : ''}
                </button>
              ))}
            </div>
          </div>

          {/* Submit CTA Button */}
          <button
            type="submit"
            disabled={!isValidAddress || isAnalyzing}
            className="px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-500 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-slate-950 font-semibold text-sm shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2 transition-all disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {isAnalyzing ? (
              <>
                <div className="h-4 w-4 border-2 border-slate-950 border-t-transparent rounded-full animate-spin" />
                <span>Attributing...</span>
              </>
            ) : (
              <>
                <Sparkles className="h-4 w-4" />
                <span>Analyze Wallet</span>
                <ArrowRight className="h-4 w-4" />
              </>
            )}
          </button>
        </div>

        {/* Validation Error Message */}
        {analysisError && (
          <div className="flex items-center gap-2 p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-300 text-xs">
            <AlertCircle className="h-4 w-4 shrink-0" />
            <span>{analysisError}</span>
          </div>
        )}
      </form>

      {/* Preset Investigation Cases */}
      {!compact && presets.length > 0 && (
        <div className="mt-5 pt-4 border-t border-slate-800/80">
          <div className="flex items-center justify-between mb-2.5">
            <span className="text-xs font-mono uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
              Demo & Benchmark Test Cases:
            </span>
            <span className="text-[11px] text-slate-500">Instant One-Click Attribution</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
            {presets.map((p, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setInputVal(p.address);
                  loadPreset(p);
                }}
                className="p-3 text-left rounded-xl bg-slate-900/60 hover:bg-slate-800/80 border border-slate-800 hover:border-cyan-500/40 transition-all group"
              >
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors">
                    {p.name.split(':')[0]}
                  </span>
                  <span className="text-[10px] font-mono px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
                    {p.primaryVaspExpected} ~{p.expectedScore}%
                  </span>
                </div>
                <p className="text-[11px] text-slate-400 line-clamp-2 leading-relaxed">
                  {p.description}
                </p>
                <div className="mt-2 text-[10px] font-mono text-slate-500 truncate">
                  {p.address}
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
