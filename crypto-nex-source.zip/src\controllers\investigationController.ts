import { Request, Response } from 'express';
import { db } from '../database/db';
import { blockchainService } from '../services/blockchain';
import { graphEngine } from '../services/graphEngine';
import { attributionEngine } from '../services/attributionEngine';
import { InvestigationCase, ScoringWeights } from '../types';

export class InvestigationController {
  /**
   * GET /api/investigations
   */
  async getInvestigations(_req: Request, res: Response) {
    try {
      const cases = await db.getInvestigations();
      return res.status(200).json({ success: true, cases, count: cases.length });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to fetch investigations', details: err.message });
    }
  }

  /**
   * GET /api/investigations/:id
   */
  async getInvestigation(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const caseItem = await db.getInvestigation(id);
      if (!caseItem) {
        return res.status(404).json({ error: 'Investigation case not found' });
      }
      return res.status(200).json({ success: true, case: caseItem });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to fetch investigation', details: err.message });
    }
  }

  /**
   * POST /api/investigations
   */
  async createInvestigation(req: Request, res: Response) {
    try {
      const { walletAddress, caseTitle, investigatorNotes, priority = 'MEDIUM', tags = [] } = req.body;

      if (!walletAddress || !caseTitle) {
        return res.status(400).json({ error: 'walletAddress and caseTitle are required.' });
      }

      const id = `case-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const now = new Date().toISOString();

      const newCase: InvestigationCase = {
        id,
        walletAddress: walletAddress.toLowerCase(),
        caseTitle,
        investigatorNotes: investigatorNotes || '',
        status: 'OPEN',
        priority,
        tags: Array.isArray(tags) ? tags : [],
        createdAt: now,
        updatedAt: now
      };

      await db.saveInvestigation(newCase);
      return res.status(201).json({ success: true, case: newCase });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to create investigation', details: err.message });
    }
  }

  /**
   * PUT /api/investigations/:id
   */
  async updateInvestigation(req: Request, res: Response) {
    try {
      const { id } = req.params;
      const updates = req.body;
      const updated = await db.updateInvestigation(id, updates);

      if (!updated) {
        return res.status(404).json({ error: 'Investigation case not found' });
      }

      return res.status(200).json({ success: true, case: updated });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to update investigation', details: err.message });
    }
  }

  /**
   * GET /api/reports/:address
   * Generate comprehensive printable/exportable investigation intelligence dossier
   */
  async generateReport(req: Request, res: Response) {
    try {
      const { address } = req.params;
      const normalized = address.toLowerCase();

      // Ensure data is up to date
      const { wallet, transactions } = await blockchainService.getWalletDetails(normalized);
      const graph = await graphEngine.buildTransactionGraph(normalized, transactions, 2);
      const attribution = await attributionEngine.computeAttribution(normalized, transactions, graph);

      const report = {
        reportId: `CRX-REP-${normalized.slice(2, 8).toUpperCase()}-${Date.now()}`,
        generatedAt: new Date().toISOString(),
        classification: 'LAW ENFORCEMENT & COMPLIANCE INTELLIGENCE / TLP:AMBER',
        targetWallet: {
          address: normalized,
          blockchain: 'Ethereum EVM',
          statistics: wallet.statistics,
          firstActivity: wallet.firstActivity,
          lastActivity: wallet.lastActivity,
        },
        attributionSummary: {
          mostLikelyVasp: attribution.mostLikelyVasp.vasp.name,
          attributionScore: attribution.mostLikelyVasp.score,
          confidenceLevel: attribution.mostLikelyVasp.confidence,
          rankings: attribution.rankings.map(r => ({
            rank: r.rank,
            vaspName: r.vasp.name,
            vaspType: r.vasp.type,
            country: r.vasp.country,
            score: `${r.score}%`,
            confidence: r.confidence,
            shortestHopDistance: r.evidence.shortestHopDistance,
            volumeOverlapETH: r.evidence.volumeOverlapETH,
            volumeOverlapPercent: `${r.evidence.volumeOverlapPercent}%`,
            directInteractions: r.evidence.directInteractionsCount,
            totalInteractions: r.evidence.totalInteractionsCount,
            isDemoData: r.isDemoAttribution
          }))
        },
        evidenceDossier: attribution.mostLikelyVasp.evidence,
        riskIndicators: attribution.riskIndicators,
        graphSummary: {
          totalNodes: graph.nodes.length,
          totalEdges: graph.edges.length,
          hopDistribution: {
            hop0_target: 1,
            hop1_direct: graph.nodes.filter(n => n.hop === 1).length,
            hop2_multi: graph.nodes.filter(n => n.hop === 2).length,
            hop3_extended: graph.nodes.filter(n => n.hop === 3).length
          },
          vaspNodesMatched: graph.nodes.filter(n => n.isVASP).map(n => ({
            label: n.label,
            vaspName: n.vaspName,
            hop: n.hop,
            volume: n.totalVolume
          }))
        },
        methodology: {
          model: 'CRYPTO-NEX Multi-Factor Graph Proximity & Behavioral Ingestion Signature v1.0',
          weightsApplied: attribution.scoringWeights,
          factors: [
            'Graph Proximity (Decay model across 1-3 shortest topological hops)',
            'Transaction Volume Overlap (Cumulative native & token flow routed to cluster)',
            'Interaction Frequency (Log-normalized transaction cardinality)',
            'Behavioral Similarity (Deposit sweep and batch timing profiling)',
            'Temporal Pattern (Burst activity alignment with exchange maintenance schedules)'
          ]
        },
        limitationsAndDisclaimer: [
          'PROBABILISTIC ATTRIBUTION: This report represents probabilistic attribution based on heuristic blockchain analysis, not mathematical or physical proof of wallet ownership.',
          'NO INDIVIDUAL IDENTIFICATION: The system does not identify natural persons or store personally identifiable information (PII).',
          'DATA INTEGRITY: Data is partitioned into Verified Public Clusters and Inferred/Demo Simulations as indicated.',
          'INDICATORS ONLY: Risk indicators denote behavioral anomalies and do not constitute proof of illicit conduct.'
        ]
      };

      return res.status(200).json({ success: true, report });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to generate report', details: err.message });
    }
  }

  /**
   * GET /api/settings/weights
   */
  async getScoringWeights(_req: Request, res: Response) {
    const weights = db.getScoringWeights();
    return res.status(200).json({ success: true, weights });
  }

  /**
   * POST /api/settings/weights
   */
  async updateScoringWeights(req: Request, res: Response) {
    try {
      const { graphProximity, transactionVolume, interactionFrequency, behavioralSimilarity, temporalPattern } = req.body;
      const sum = (Number(graphProximity) || 0) + (Number(transactionVolume) || 0) + (Number(interactionFrequency) || 0) + (Number(behavioralSimilarity) || 0) + (Number(temporalPattern) || 0);
      
      if (Math.abs(sum - 1.0) > 0.05 && Math.abs(sum - 100) > 5) {
        return res.status(400).json({ error: 'Weights must sum to approximately 1.0 (or 100%).' });
      }

      const normalizedWeights: Partial<ScoringWeights> = {
        graphProximity: sum > 5 ? graphProximity / 100 : Number(graphProximity),
        transactionVolume: sum > 5 ? transactionVolume / 100 : Number(transactionVolume),
        interactionFrequency: sum > 5 ? interactionFrequency / 100 : Number(interactionFrequency),
        behavioralSimilarity: sum > 5 ? behavioralSimilarity / 100 : Number(behavioralSimilarity),
        temporalPattern: sum > 5 ? temporalPattern / 100 : Number(temporalPattern)
      };

      const updated = db.setScoringWeights(normalizedWeights);
      return res.status(200).json({ success: true, weights: updated });
    } catch (err: any) {
      return res.status(500).json({ error: 'Failed to update weights', details: err.message });
    }
  }
}

export const investigationController = new InvestigationController();
