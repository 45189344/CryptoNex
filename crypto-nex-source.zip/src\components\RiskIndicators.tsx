import React from 'react';
import { useApp } from '../context/AppContext';
import { ShieldAlert, AlertTriangle, Info, AlertOctagon, CheckCircle2 } from 'lucide-react';
import { RiskIndicator } from '../types';

export const RiskIndicators: React.FC = () => {
  const { attribution, isAnalyzing } = useApp();

  if (isAnalyzing || !attribution) return null;

  const indicators = attribution.riskIndicators;

  const getSeverityBadge = (severity: RiskIndicator['severity']) => {
    switch (severity) {
      case 'CRITICAL':
        return { bg: 'bg-rose-500/20 text-rose-300 border-rose-500/40', icon: AlertOctagon };
      case 'HIGH':
        return { bg: 'bg-amber-500/20 text-amber-300 border-amber-500/40', icon: AlertTriangle };
      case 'MEDIUM':
        return { bg: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/40', icon: AlertTriangle };
      default:
        return { bg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40', icon: Info };
    }
  };

  return (
    <div className="p-6 rounded-2xl glass-panel space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-slate-200 font-display flex items-center gap-2">
            <ShieldAlert className="h-4 w-4 text-amber-400" />
            Behavioral & Compliance Risk Indicators
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Automated heuristic detection of non-standard settlement patterns
          </p>
        </div>
        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700">
          Indicators Only
        </span>
      </div>

      {indicators.length === 0 ? (
        <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 flex items-center gap-3 text-emerald-400 text-xs">
          <CheckCircle2 className="h-4 w-4" />
          <span>No critical behavioral anomalies or sanctioned mixer proximity detected.</span>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {indicators.map((ind) => {
            const style = getSeverityBadge(ind.severity);
            const Icon = style.icon;
            return (
              <div
                key={ind.id}
                className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2 hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className="h-4 w-4 text-amber-400" />
                    <span className="text-xs font-bold text-slate-200">{ind.title}</span>
                  </div>
                  <span className={`text-[10px] font-mono font-semibold px-2 py-0.5 rounded border ${style.bg}`}>
                    {ind.severity}
                  </span>
                </div>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {ind.description}
                </p>
              </div>
            );
          })}
        </div>
      )}

      {/* Compliance Note */}
      <div className="text-[10px] text-slate-500 bg-slate-950/40 p-2.5 rounded-lg border border-slate-800/60 leading-tight">
        ⚠️ <span className="font-semibold text-slate-400">Important Compliance Statement:</span> Risk indicators are probabilistic behavioral signals designed for investigator triage. They do not constitute proof of criminal misconduct.
      </div>
    </div>
  );
};
