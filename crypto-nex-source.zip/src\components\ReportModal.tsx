import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { 
  X, Printer, Download, Copy, Shield, 
  FileText, CheckCircle2, AlertTriangle, Layers, Info 
} from 'lucide-react';

export const ReportModal: React.FC = () => {
  const { isReportModalOpen, setIsReportModalOpen, attribution, wallet, graph } = useApp();
  const [copied, setCopied] = useState(false);

  if (!isReportModalOpen || !attribution || !wallet) return null;

  const handlePrint = () => {
    window.print();
  };

  const handleCopyJSON = () => {
    const reportData = {
      reportId: `CRX-REP-${wallet.address.slice(2, 8).toUpperCase()}-${Date.now()}`,
      generatedAt: new Date().toISOString(),
      targetWallet: {
        address: wallet.address,
        blockchain: wallet.blockchain,
        statistics: wallet.statistics,
      },
      attribution: attribution.mostLikelyVasp,
      rankings: attribution.rankings,
      riskIndicators: attribution.riskIndicators,
      graphSummary: {
        totalNodes: graph?.nodes.length || 0,
        totalEdges: graph?.edges.length || 0,
      },
      methodology: attribution.scoringWeights,
      disclaimer: attribution.disclaimer
    };

    navigator.clipboard.writeText(JSON.stringify(reportData, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="w-full max-w-4xl max-h-[90vh] rounded-2xl glass-panel border-cyan-500/40 flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        {/* Modal Header & Controls */}
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-950/80 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center">
              <FileText className="h-5 w-5 text-cyan-400" />
            </div>
            <div>
              <h3 className="text-base font-bold font-display text-slate-100">
                Investigation Intelligence Dossier
              </h3>
              <p className="text-[11px] font-mono text-slate-400">
                Official Law Enforcement & Compliance Probabilistic Report
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopyJSON}
              className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-mono text-slate-300 flex items-center gap-1.5 transition-colors"
            >
              <Copy className="h-3.5 w-3.5" />
              <span>{copied ? 'JSON Copied' : 'Copy JSON'}</span>
            </button>
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 rounded-lg bg-gradient-to-r from-cyan-600 to-indigo-600 hover:from-cyan-500 hover:to-indigo-500 text-white text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-cyan-900/30 transition-all"
            >
              <Printer className="h-3.5 w-3.5" />
              <span>Print / PDF</span>
            </button>
            <button
              onClick={() => setIsReportModalOpen(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800 transition-colors ml-2"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Printable Report Body */}
        <div className="p-6 md:p-8 space-y-6 overflow-y-auto print:p-0 print:bg-white print:text-black">
          {/* Official Banner */}
          <div className="border border-cyan-500/30 rounded-xl p-4 bg-cyan-950/20 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Report Reference</span>
              <span className="font-bold text-cyan-300">
                CRX-REP-{wallet.address.slice(2, 8).toUpperCase()}-{Date.now().toString().slice(-6)}
              </span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Classification</span>
              <span className="font-bold text-amber-300">TLP:AMBER / LAW ENFORCEMENT & COMPLIANCE</span>
            </div>
            <div>
              <span className="text-slate-400 block text-[10px] uppercase">Timestamp</span>
              <span className="text-slate-300">{new Date().toUTCString()}</span>
            </div>
          </div>

          {/* Section 1: Executive Summary */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider font-bold text-cyan-400 border-b border-slate-800 pb-1">
              1. Executive Attribution Summary
            </h4>
            <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-3">
              <p className="text-xs text-slate-300 leading-relaxed">
                Automated multi-hop graph traversal and 5-factor behavioral heuristic scoring have identified{' '}
                <strong className="text-white font-semibold">{attribution.mostLikelyVasp.vasp.name}</strong> as the most likely associated Virtual Asset Service Provider (VASP) for subject wallet{' '}
                <code className="text-cyan-300 font-mono">{wallet.address}</code> with an attribution probability of{' '}
                <strong className="text-emerald-400 font-bold">{attribution.mostLikelyVasp.score}%</strong> (Confidence Rating: {attribution.mostLikelyVasp.confidence}).
              </p>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono pt-2 border-t border-slate-800">
                <div>
                  <span className="text-slate-500 text-[10px] block">Primary VASP</span>
                  <span className="font-bold text-slate-200">{attribution.mostLikelyVasp.vasp.name}</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Score</span>
                  <span className="font-bold text-emerald-400">{attribution.mostLikelyVasp.score}%</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Topology Distance</span>
                  <span className="font-bold text-cyan-300">{attribution.mostLikelyVasp.evidence.shortestHopDistance} Hop(s)</span>
                </div>
                <div>
                  <span className="text-slate-500 text-[10px] block">Volume Channel</span>
                  <span className="font-bold text-slate-200">{attribution.mostLikelyVasp.evidence.volumeOverlapETH} ETH</span>
                </div>
              </div>
            </div>
          </div>

          {/* Section 2: Candidate Rankings Leaderboard */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider font-bold text-cyan-400 border-b border-slate-800 pb-1">
              2. Candidate VASP Probabilistic Rankings
            </h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-900/80 text-slate-400 text-[10px] uppercase border-b border-slate-800">
                  <tr>
                    <th className="p-2.5">Rank</th>
                    <th className="p-2.5">VASP Name</th>
                    <th className="p-2.5">Type / Jurisdiction</th>
                    <th className="p-2.5">Score</th>
                    <th className="p-2.5">Confidence</th>
                    <th className="p-2.5">Shortest Hop</th>
                    <th className="p-2.5">Volume Overlap</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-slate-300">
                  {attribution.rankings.map((r) => (
                    <tr key={r.vasp.id}>
                      <td className="p-2.5 font-bold">#{r.rank}</td>
                      <td className="p-2.5 font-semibold text-slate-100">{r.vasp.name}</td>
                      <td className="p-2.5 text-slate-400">{r.vasp.type} ({r.vasp.country})</td>
                      <td className="p-2.5 font-bold text-cyan-300">{r.score}%</td>
                      <td className="p-2.5">{r.confidence}</td>
                      <td className="p-2.5">{r.evidence.shortestHopDistance} Hop(s)</td>
                      <td className="p-2.5">{r.evidence.volumeOverlapETH} ETH</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* Section 3: Target Wallet Telemetry */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider font-bold text-cyan-400 border-b border-slate-800 pb-1">
              3. Target Wallet Forensic Statistics
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs font-mono">
              <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Total Volume</span>
                <span className="font-bold text-slate-200">{wallet.statistics.totalVolumeETH} ETH</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Transactions (In/Out)</span>
                <span className="font-bold text-slate-200">
                  {wallet.statistics.incomingTransactions} IN / {wallet.statistics.outgoingTransactions} OUT
                </span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Unique Counterparties</span>
                <span className="font-bold text-slate-200">{wallet.statistics.uniqueCounterparties}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/50 border border-slate-800">
                <span className="text-slate-500 text-[10px] block">Velocity</span>
                <span className="font-bold text-slate-200">{wallet.statistics.velocityPerHour} tx/hr</span>
              </div>
            </div>
          </div>

          {/* Section 4: Behavioral & Compliance Risk Indicators */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider font-bold text-cyan-400 border-b border-slate-800 pb-1">
              4. Behavioral Risk & Intelligence Indicators
            </h4>
            <div className="space-y-2">
              {attribution.riskIndicators.map((ind) => (
                <div key={ind.id} className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 flex items-start gap-2.5 text-xs">
                  <AlertTriangle className="h-4 w-4 text-amber-400 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-bold text-slate-200">{ind.title} ({ind.severity}): </span>
                    <span className="text-slate-400">{ind.description}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Section 5: Methodology & Mandatory Compliance Disclaimers */}
          <div className="space-y-3">
            <h4 className="text-xs font-mono uppercase tracking-wider font-bold text-cyan-400 border-b border-slate-800 pb-1">
              5. Methodology & Legal Compliance Disclaimers
            </h4>
            <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-2 text-[11px] text-slate-400 leading-relaxed">
              <p>
                <strong>PROBABILISTIC ATTRIBUTION:</strong> This report is generated through mathematical graph topology analysis, on-chain clustering, and behavioral heuristics. It represents probabilistic attribution, NOT proof of wallet ownership or natural person identification.
              </p>
              <p>
                <strong>COMPLIANCE BOUNDARIES:</strong> The platform does not store or process natural person PII. All cluster data is segregated into Publicly Verified Registries vs Demo Simulations.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
